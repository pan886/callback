/**
 * @file aip32rv15xx_icache.h
 * @brief This file contains all the functions prototypes for the ICACHE firmware library. 
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-01-07
 * @copyright Copyright (c) 2024 I-core, Inc
 */

#ifndef __AiP32RV15A8_ICACHE_H
#define __AiP32RV15A8_ICACHE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "aip32rv15xx.h"

/**
 * @brief Instruction cache enable.
 */
static inline void __icache_enable()
{
    ICACHE->ENABLE.EN_BIT = 1;
}

/**
 * @brief Instruction cache disable.
 */
static inline void __icache_disable()
{
    ICACHE->ENABLE.EN_BIT = 0;
}

/**
 * @brief Instruction cache flush.
 */
static inline void __icache_flush()
{
    ICACHE->FLUSH.FLUSH_BIT = 1;
}

#ifdef __cplusplus
}
#endif

#endif
