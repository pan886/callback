/**
 * @file aip32rv15xx_flash.h
 * @brief This file contains all the functions prototypes for the FLASH firmware library. \n
 * (+) At first, use FLASH_Unlock(...) to unlock the flash. \n
 * (+)  you can use FLASH_GetStatus(...) to get the state of the FLASH at any time. \n
 * (+) Finally, use FLASH_Lock(...) to lock the flash.
 * @author MCD Application Team
 * @version 1.0
 * @date 2024-06-21
 * @copyright Copyright (c) 2024 i-core, Inc
 */
#ifndef __AiP32RV15A8_FLASH_H
#define __AiP32RV15A8_FLASH_H

#ifdef __cplusplus
extern "C" {
#endif

#include "aip32rv15xx.h"
#define EFC_CTRL_OFFSET 0x00000000
#define EFC_CFG0_OFFSET 0x00000004
#define EFC_CFG1_OFFSET 0x00000008
#define EFC_CFG2_OFFSET 0x0000000c
#define EFC_CFG3_OFFSET 0x00000010
#define EFC_CFG4_OFFSET 0x00000014
#define EFC_CFG5_OFFSET 0x00000018
#define EFC_CFG6_OFFSET 0x0000001c
#define EFC_CFG7_OFFSET 0x00000020
#define EFC_CMD_OFFSET 0x00000030
#define EFC_LOCK_OFFSET 0x00000034
#define EFC_STS0_OFFSET 0x00000038
#define EFC_ERR_CLR_OFFSET 0x0000003c
#define EFC_TRIM_REG0 0x00000070
#define EFC_TRIM_REG1 0x00000074
#define EFC_TRIM_REG2 0x00000078
#define EFC_TRIM_REG3 0x0000007c
#define EFC_TRIM_REG4 0x00000080
#define EFC_TRIM_REG5 0x00000084
#define EFC_TRIM_REG6 0x00000088
#define EFC_TRIM_REG7 0x0000008c
#define EFC_BAD_SEC_REG0 0x00000090
#define EFC_BAD_SEC_REG1 0x00000094
#define EFC_CONFIG_FLAG_REG 0x00000100
#define EFC_FlASH_OBR 0x00000180
#define EFC_FLASH_OPT_KEY 0x00000184
#define EFC_NVR_PRT_REG 0x00000190
#define OPT_BYTE_OFFSET 0x00020bf0
#define EFC_BASE         0x4001C000
/**
 * @brief FLASH Status.
 */
typedef enum {
    FLASH_BUSY = 1,   /**< FLASH busy. */
    FLASH_ERROR_UNAL, /**< FLASH program address unalign error. */
    FLASH_ERROR_BUS,  /**< FLASH bus transfer error. */
    FLASH_COMPLETE,   /**< FLASH idle. */
    FLASH_TIMEOUT     /**< FLASH operation time out. */
} FLASH_Status;

typedef enum
{
	FLASH_CFG_VALID,
	FLASH_CFG_INVALID
}FLASH_CFG_Status;

#define FLASH_PrefetchBuffer_Enable  ((uint32_t)0x1) /**< FLASH Prefetch Buffer Enable. */
#define FLASH_PrefetchBuffer_Disable ((uint32_t)0x0) /**< FLASH Prefetch Buffer Disable. */

#define FLASH_FLAG_BUS_ERR  ((uint32_t)0x0) /**< FLASH bus transfer error flag. */
#define FLASH_FLAG_UNAL_ERR ((uint32_t)0x1) /**< FLASH program address unalign error flag. */


/**
 * @brief Update the code latency value, if AHB frequency is changed, that it must be called to ensure correct Flash access settings.
 */
void FLASH_UpdateLatency(void);

/**
 * @brief Enables or disables the Prefetch Buffer.
 * @param[in] FLASH_PrefetchBuffer specifies the Prefetch buffer status.
 *   This parameter can be one of the following values: \n
 *     FLASH_PrefetchBuffer_Enable: FLASH Prefetch Buffer Enable; \n
 *     FLASH_PrefetchBuffer_Disable: FLASH Prefetch Buffer Disable; \n
 */
void FLASH_PrefetchBufferCmd(uint32_t FLASH_PrefetchBuffer);

/**
 * @brief Checks whether the FLASH Prefetch Buffer status is set or not.
 * @return FlagStatus FLASH Prefetch Buffer Status (SET or RESET).
 */
FlagStatus FLASH_GetPrefetchBufferStatus(void);

/**
 * @brief Unlocks the FLASH Program Erase Controller.
 */
void FLASH_Unlock(void);

/**
 * @brief Locks the FLASH Program Erase Controller.
 */
void FLASH_Lock(void);

/**
 * @brief Erase the whole chip.
 * @Return the Program Status.
 */
FLASH_Status FLASH_EraseChip(void);


/**
 * @brief Erase the sector.
 * @param[in] Address Started to be erased.
 * @Return the Program Status.
 */
FLASH_Status FLASH_EraseSector(uint32_t Sector_Address);

/**
 * @brief Erase the Block.
 * @param[in] Address Started to be erased.
 * @Return the Program Status.
 */
FLASH_Status FLASH_EraseBlock(uint32_t Block_Address);

/**
 * @brief Gain write access (Program/Erase) to the option bytes.
 */
void Disable_Option_Write_protection(void);


/**
 * @brief Programs a double word at a specified address.
 * @param[in] Address specifies the address to be programmed, must be 8 bytes aligned.
 * @param[in] Data specifies the uint64_t data to be programmed.
 * @return FLASH_Status The returned value can be: FLASH_BUSY, FLASH_ERROR_UNAL,
 *         FLASH_ERROR_BUS, FLASH_COMPLETE or FLASH_TIMEOUT.
 */
FLASH_Status FLASH_ProgramDoubleWord(uint32_t Address, uint64_t Data);

/**
 * @brief Write protects the desired pages.
 * @param[in] FLASH_Pages specifies the address of the pages to be write protected.
 * @return FLASH_Status The returned value can be: FLASH_BUSY, FLASH_ERROR_UNAL,
 *         FLASH_ERROR_BUS, FLASH_COMPLETE or FLASH_TIMEOUT.
 */
FLASH_Status FLASH_EnableWriteProtection(uint32_t FLASH_Pages);

/**
 * @brief Checks whether the specified FLASH flag is set or not.
 * @param[in] FLASH_FLAG specifies the FLASH flag to check.
 * @return FlagStatus FLASH Prefetch Buffer Status (SET or RESET).
 */
FlagStatus FLASH_GetFlagStatus(uint32_t FLASH_FLAG);

/**
 * @brief Clears the FLASH's pending flags.
 * @param[in] FLASH_FLAG specifies the FLASH flag to clear.
 */
void FLASH_ClearFlag(uint32_t FLASH_FLAG);

/**
 * @brief Returns the FLASH Status.
 * @return FLASH_Status The returned value can be: FLASH_BUSY, FLASH_ERROR_UNAL,
 *         FLASH_ERROR_BUS, FLASH_COMPLETE or FLASH_TIMEOUT.
 */
FLASH_Status FLASH_GetStatus(void);

/**
 * @brief Waits for a Flash operation to complete or a TIMEOUT to occur.
 * @param[in] Timeout FLASH programming Timeout
 * @return FLASH_Status The returned value can be: FLASH_BUSY, FLASH_ERROR_UNAL,
 *         FLASH_ERROR_BUS, FLASH_COMPLETE or FLASH_TIMEOUT.
 */
FLASH_Status FLASH_WaitForLastOperation(uint32_t Timeout);

#ifdef __cplusplus
}
#endif

#endif
