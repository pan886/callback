/*
 * @file: aip32rv15xx_eclic.h
 * @brief: This file contains all the functions prototypes for the eclic firmware library.
 * @Author: MCD Application Team.
 * @version 1.0
 * @date 2024-05-16
 * @copyright Copyright (c) 2024 I-core, Inc
 */

#ifndef AiP32RV15A8_ECLIC_H_
#define AiP32RV15A8_ECLIC_H_
#include "core_feature_base.h"
#include "core_feature_eclic.h"
#include "core_feature_timer.h"
#include <nmsis_core.h>

int32_t ECLIC_Register_IRQ(IRQn_Type IRQn, uint8_t shv,
                           ECLIC_TRIGGER_Type trig_mode, uint8_t lvl,
                           uint8_t priority, void *handler);

void Exception_Register_EXC(uint32_t EXCn, unsigned long exc_handler);

uint32_t core_exception_handler(unsigned long mcause, unsigned long sp);
#endif /* APPLICATION_ECLIC_H_ */
