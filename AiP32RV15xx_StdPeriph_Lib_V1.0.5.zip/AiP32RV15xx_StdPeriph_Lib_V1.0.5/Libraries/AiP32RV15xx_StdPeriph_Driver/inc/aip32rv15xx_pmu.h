/*
 * @file  aip32rv15xx_pmu.h
 * @brief This file contains all the functions prototypes for the PMU firmware library.
 * @author MCD Application Team
 * @date 2024-04-27
 * @copyright Copyright (c) 2024 I-core, Inc.
 */



#ifndef __AiP32RV15A8_PMU_H_
#define __AiP32RV15A8_PMU_H_
#include "aip32rv15xx.h"

extern void EXTI0_IRQHandler(void) ;


/* PMU command constants definitions */
#define WFI_CMD ((uint8_t)0x00U) /*!< use WFI command */
#define WFE_CMD ((uint8_t)0x01U) /*!< use WFE command */

typedef enum
{
    MCU_SLEEP_MODE,
    POWERUP_MODE,
    MCU_ACTIVE_MODE,
    MCU_POWERDOWN_STATE,
    MCU_STANDBY_STATE

} Power_State;

typedef enum
{
	Wakeup_from_PA0 = 0x1,
	Wakeup_from_RTC = 0x3,
} wakeup_state;


typedef enum
{
	boot_from_por_resset,
	boot_from_wakingup

}Boot_state;

typedef enum
{

	pull_down,
	pull_up

}PA0_pull_mode;



/**
 * @brief MCU enter standby mode.
 */
void enter_standby_mode(void);

/**
 * @brief MCU enter sleep mode.
 * @param[in] sleepmodecmd:WFI or WFE.
 */
void enter_sleepmode(uint8_t sleepmodecmd);

/**
 * brief get the state of the power.
 * @return  Power_State the state of the power.
 */
Power_State pmu_power_state(void);

/**
 * brief get the state of the boot.
 * @return  Boot_State the state of the Boot.
 */
Boot_state Pmu_get_boot_state(void);

/**
 * brief get the state of wakeup.
 * @return wakeup_state :the state of wakeup.
 */
wakeup_state pmu_wakeup_state(void);

/**
 * @brief MCU enter stop mode.
 */
void enter_stop_mode(void);

void PMU_PA0(PA0_pull_mode pull_mode);

#endif

