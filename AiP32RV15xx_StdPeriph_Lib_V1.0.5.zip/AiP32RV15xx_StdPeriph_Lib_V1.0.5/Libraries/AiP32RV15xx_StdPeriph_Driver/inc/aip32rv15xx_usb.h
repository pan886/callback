/**
 * @file aip32rv15xx_usb.h
 * @brief This file contains all the functions prototypes for the USB firmware library.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-11-20
 * @copyright Copyright (c) 2024 I-core, Inc
 */

#include "aip32rv15xx.h"

#ifdef __cplusplus
extern "C" {
#endif
#define CONFIG_EP(X) (USB_BASE + 0x100 + 0x10 * X)

#define USB_DMA_ENABLE_SHIFT     0
#define USB_DMA_TRANSMIT_SHIFT   1
#define USB_DMA_MODE1_SHIFT      2
#define USB_DMA_IRQENABLE_SHIFT  3
#define USB_DMA_ENDPOINT_SHIFT   4
#define USB_DMA_BUSERROR_SHIFT   8
#define USB_DMA_BURSTMODE_SHIFT  9
#define USB_DMA_BURSTMODE        (3 << USB_DMA_BURSTMODE_SHIFT)
#define USB_DMA_BURSTMODE_UNSPEC 0
#define USB_DMA_BURSTMODE_INCR4  1
#define USB_DMA_BURSTMODE_INCR8  2
#define USB_DMA_BURSTMODE_INCR16 3

#define USB_DMA_CHANNELS 8

#define USB_DMA_BASE    0x200
#define USB_DMA_INTR    USB_DMA_BASE
#define USB_DMA_CONTROL 0x4
#define USB_DMA_ADDRESS 0x8
#define USB_DMA_COUNT   0xc

/* only EP0 ~ Ep7 is Available*/
typedef enum {
    EP0, /**< endpoint 0.*/
    EP1, /**< endpoint 1.*/
    EP2, /**< endpoint 2.*/
    EP3, /**< endpoint 3.*/
    EP4, /**< endpoint 4.*/
    EP5, /**< endpoint 5.*/
    EP6, /**< endpoint 6.*/
    EP7  /**< endpoint 7.*/

} EP_NUM;

/**
 * @brief USB transfer speed.
 */
typedef enum {
    USB_SPEED_LOW,
    USB_SPEED_FULL

} USB_SPEED;

/**
 * @brief USB transfer PROTOCOL.
 */
typedef enum {

    CONTROL,
    ISOCHRONOUS,
    BULK,
    INTERRUPT
} PROTOCOL;

/**
 * @brief USB transfer direction .
 */
typedef enum {

    RX,
    TX,

} USB_TRANSFER_TYPE;

/**
 * @brief the struct of USB transfer tyoedef.
 */
typedef struct
{

    uint8_t SPEED;
    uint8_t PROTOCOL;
    uint8_t EP_NUM;
} USB_HOST_TXRXTYPE_TypeDef;

typedef struct
{
    uint8_t PROTOCOL;
    uint8_t EP_NUM;
} USB_Device_TYPE_TypeDef;

/**
 * @brief the struct of usb dma channel typedef.
 */
typedef struct {

    uint32_t START_ADDR;
    uint32_t LENGTH;
    uint16_t MAX_PACKET_SZ;
    uint8_t  IDX;
    uint8_t  EPNUM;
    uint8_t  TRANSMIT;
    uint8_t  MODE;
} Usb_Dma_Channel_TypeDef;



/**
 * @brief  Enables or disables usb soft connect.
 * @param[in] NewState New state of usb soft connect.
 */
void Usb_Soft_Connect(FunctionalState NewState);

/**
 * @brief Set the USB in the host mode.
 *
 */
void Usb_Set_Host_Mode();

/**
 * @brief wait usb enter the host mode.
 *
 */
void Usb_Host_Wait();

/**
 * @brief HOST set address of the device or device store the address from the Host.
 * @param[in] Address The address of usb device.
 */
void Usb_Set_Address(uint8_t Address);

/**
 * @brief USB host start to transmit data.
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Host_Tx_Start(uint8_t Epnum);

/**
 * @brief  Enables or disables USB all interrupts.
 * @param[in] NewState new state of usb all interrupts.
 */
void Usb_All_Interrupts(FunctionalState NewState);

/**
 * @brief  Usb host flush the latest packet from the endpoint TX FIFO.
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Host_Tx_Flush_Fifo(uint8_t Epnum);

/**
 * @brief Return the last received frame number.
 *
 * @return uint16_t: The value of last received frame number.
 */
uint16_t Usb_Host_Get_Frame_Number(void);

/**
 * @brief Set by the CPU to generate Resume signaling when the device is in Suspend mode.

 * @param[in] NewState new state of usb resume.
 */
void Usb_Host_Resume(FunctionalState NewState);

/**
 * @brief Set the new state of usb reset.
 * @param[in] NewState new state of  usb reset.
 */
void Usb_Host_Reset(FunctionalState NewState);

/**
 * @brief USB host enter the suspend mode .
 *
 */
void Usb_Host_Suspend(void);

/**
 * @brief Enables or disables USB ISO update.
 * @param[in] NewState new state of ISO update.
 */
void Usb_ISO_Update(FunctionalState NewState);

/**
 * @brief Stop the USB BUS.
 *
 */
void Usb_Stop(void);

/**
 * @brief Enables or disables the USB RX interrupt.
 *
 * @param Epnum the index of endpoint.
 * @param NewState the state of the RX interrupt.
 */
void Usb_RX_Interrupt_Enable(uint8_t Epnum, FunctionalState NewState);

/**
 * @brief Set the interrupt of the specific endpoint TX.
 *
 * @param Epnum the index of endpoint.
 * @param NewState the state of the TX interrupt.
 */
void Usb_TX_Interrupt(uint8_t Epnum, FunctionalState NewState);

/**
 * @brief USB host request an IN transaction.
 *
 * @param EP_NUM the index of endpoint.
 */
void Usb_Host_Req_IN_transaction(uint8_t EP_NUM);

/**
 * @brief  Flush the RX fifo.
 * @param[in] EP_NUM the index of endpoint.
 */
void Usb_Host_Flush_Rxfifo(uint8_t EP_NUM);

/**
 * @brief  Config the information of the usb speed,Protocol,Target Endpoint Number,Tx or RX.
 * @param[in] USB_HOST_TXRXTYPE  Pointer to a HOST_RXTYPE_TypeDef structure that contains the configuration
 * information for the host rx type.
 * @param[in] Type TX or Rx.
 */
void Usb_Host_Tx_RX_Type(USB_HOST_TXRXTYPE_TypeDef *USB_HOST_TXRXTYPE, USB_TRANSFER_TYPE Type);

/**
 * @brief return the number of data bytes in the packet currently in line to be read from the Rx FIFO.
 * @param[in] EP_NUM  the index of endpoint.
 * @return uint16_t  the number of data bytes.
 */
uint16_t Usb_Receive_Count(uint8_t EP_NUM);

/**
 * @brief USE host send a SETUP token for the transaction.
 * @param[in] EP_NUM the index of endpoint.
 */
void Usb_Host_Transmit_Setup(uint8_t EP_NUM);

/**
 * @brief  USE host send OUT token for the transaction.
 * @param[in] EP_NUM The index of endpoint.
 */
void Usb_Host_Out_Transaction(uint8_t EP_NUM);

/**
 * @brief Set the address of target.
 *
 * @param[in] Address The address of target.
 */
void Usb_Host_Set_Address(uint8_t Address);

/**
 * @brief  USB host receive the date of the target.
 * @param[in] EP_NUM the index of endpoint.
 * @param[in] Buffer the buffer of the receive data.
 */
void Usb_Host_Receive_data(uint8_t EP_NUM, uint8_t Buffer[]);

/**
 * @brief Sets the number of framesafter which Endpoint 0 should timeout on receiving
 *  a stream of NAK responsesor defines the polling interval for the currently-selected TX endpoint.
 * @param[in] EP_NUM The index of endpoint.
 * @param[in] NAK_Interval NAK Interval for the currently-selected TX endpoint.
 * @param[in] NewState This parameter can take the value ENABLE or DISABLE.
 */
void Usb_Set_NAK_Interval(uint8_t EP_NUM, uint8_t NAK_Interval, FunctionalState NewState);

/**
 * @brief  Toggle the data of specific endpoints.
 * @param[in] EP_NUM The index of endpoint.
 */
void Usb_Host_Toggle_Data(uint8_t EP_NUM);

/**
 * @brief  Loads data into the TxFIFO for the corresponding endpoint FIFO.
 * @param[in] EP_Num The index of endpoint.
 * @param[in] Buffer  The buffer of data to write.
 * @param[in] Length The length of the data to write.
 */
void Usb_Write_Fifo(uint8_t EP_Num, const uint8_t Buffer[], uint8_t Length);

/**
 * @brief Unloads data from the RxFIFO for the corresponding endpoint FIFO.
 * @param[in] Epnum The index of endpoint.
 * @param[in] Buffer The buffer of data to read.
 * @param[in] Length The length of the data to read.
 * @return uint8_t* :return the buffer of data to read.
 */
uint8_t *Usb_Read_Fifo(uint8_t Epnum, uint8_t Buffer[], uint8_t Length);

/**
 * @brief USB device transmit the data of the corresponding endpoint FIFO.
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Device_Transmiit(uint8_t Epnum);

/**
 * @brief  USB device flush the corresponding endpoint FIFO.
 *
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Device_Flush_fifo(uint8_t Epnum);

/**
 * @brief USB device sets this bit:
1.  When setting TxPktRdy for the last data packet.
2.  When clearing RxPktRdy after unloading the last data packet.
3.  When setting TxPktRdy for a zero length data packet.
 *
 */
void Usb_Device_Data_End(void);

/**
 * @brief USB device clear the SetupEnd bit.
 *
 */
void Usb_Device_Clear_Setup(void);

/**
 * @brief USB device clear the RxPktRdy bit.
 *
 */
void Usb_Device_Clear_RXPktRdy(void);

/**
 * @brief USb device set tx or rx type(except ep0).
 * @param[in] Epnum The index of endpoint.
 * @param[in] type transmit or receive.
 */
void Usb_Device_Tx_RX_Type(uint8_t Epnum, USB_TRANSFER_TYPE type);
//void Usb_Device_Tx_RX_Type(USB_Device_TXRXTYPE_TypeDef  *USB_Device_TYPE, USB_TRANSFER_TYPE type);

/**
 * @brief USB device terminate the current transaction.
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Device_Send_Stall(uint8_t Epnum);

/**
 * @brief Enables or disables the USB session.
 * @param[in] NewState the state of the session.
 */
void Usb_Start_Session(FunctionalState NewState);

/**
 * @brief USB Device wait VBUS_VALID.
 */
void Usb_Wait_Vbusvalid(void);

/**
 * @brief congfig the DMA of USB.
 * @param[in] channel point to usb_dma_channel struct.
 */
void Usb_Dma_Config(Usb_Dma_Channel_TypeDef *channel);

/**
 * @brief  Start the DMA RX function.
 * @param[in] Epnum The index of endpoint.
 */
void Usb_Host_Rx_Dma_Start(uint8_t Epnum);

