/**
 * @file aip32rv15xx_system.h
 * @brief AiP32RV15A8 Device Peripheral Access Layer System Header File.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-01-07
 * @copyright Copyright (c) 2024 i-core, Inc
 */

#ifndef __AiP32RV15A8_SYSTEM_H
#define __AiP32RV15A8_SYSTEM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "aip32rv15xx.h"

/**
 * @brief early system initialization.
 */
extern void _SysInit(void);

#ifdef __cplusplus
}
#endif

#endif
