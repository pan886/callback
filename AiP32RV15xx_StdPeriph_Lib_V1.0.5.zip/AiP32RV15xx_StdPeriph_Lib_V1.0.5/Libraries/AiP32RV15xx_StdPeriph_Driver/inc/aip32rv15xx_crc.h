/**
 * @file aip32rv15xx_crc.h
 * @brief This file contains all the functions prototypes for the CRC firmware library. \n
 *         How to use this driver? \n
 * (+) At first, use RCC_AHBPeriphClockCmd(...) to enable the CRC clock. \n
 * (+) Then use CRC_SeedConfig(...) to config the the initial value of crc. \n
 * (+) Finally, use CRC_CalCRC(...) to get the crc value.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-05-17
 * @copyright Copyright (c) 2024 I-core, Inc
 */
#ifndef AiP32RV15A8_CRC_H
#define AiP32RV15A8_CRC_H

#include "aip32rv15xx.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CRC_Reverse     ((uint8_t)0x01) /**< CRC input reverse.*/
#define CRC_Not_Reverse ((uint8_t)0x00) /**< CRC input not reverse.*/
#define CRC_16          ((uint8_t)0x01) /**< CRC16 mode.*/
#define CRC_32          ((uint8_t)0x00) /**< CRC32 mode.*/

/**
 * @brief Resets the CRC Data register (DR).
 */
void CRC_ResetDR(void);

/**
 * @brief Computes the 32-bit CRC of a given data word(32-bit).
 * @param[in] Data data word(16-bit) to compute its CRC.
 * @return uint16_t 16-bit CRC.
 */
uint32_t CRC_CalcCRC(uint32_t Data);

/**
 * @brief Returns the current CRC value.
 * @return uint16_t 16-bit CRC.
 */
uint32_t CRC_GetCRC(void);

/**
 * @brief CRC input inversion.
 * @param[in] invout can be 0x1 0r 0x0;
 * @param[in] crc_mode select crc16 0r crc32.
 */
void CRC_InputControl(uint8_t invout, uint8_t crc_mode);

/**
 * @brief Clear last calculated value.
 */
void CRC_ClearValue(void);


/**
 * @brief Config CRC seed value.
 * @param[in] value  The initial value of crc before CRC computation.
 */
void CRC_SeedConfig(uint32_t value);

/**
 * @brief  Computes the 16-bit CRC of a given buffer of data word(32-bit).
 * @param[in] pBuffer Pointer to the buffer containing the data to be computed.
 * @param[in] BufferLength Length of the buffer to be computed.
 * @return uint32_t 16-bit CRC or 32-bit CRC.
 */
uint32_t CRC_CalcBlockCRC(uint32_t pBuffer[], uint32_t BufferLength);

#ifdef __cplusplus
}
#endif

#endif
