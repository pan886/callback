/**
 * @file aip32rv15xx_debug.h
 * @brief This file contains all the functions prototypes for the debug library.
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-02-27
 * @copyright Copyright (c) 2022 I-core, Inc
 */

#ifndef __AiP32RV15A8_DEBUG_H
#define __AiP32RV15A8_DEBUG_H

#define NULL             ((void *)0)
#define UART_BOOT_PORT   USART2
#define UART_DEBUG_PORT  USART2
#define UART_PARITY_NONE USART_Parity_No
#define UART_STOPBITS_1  USART_StopBits_1
#define UART_DATABITS_8  USART_WordLength_8b
#define UART_BOOT_BD     115200

#define AFIO_BASE_ADDR 0x40010000 /* AFIO */
/* IO MUX select. offset: 0xA0 */
#define AFIO_PIN_REMAP_CTL              (AFIO_BASE_ADDR + 0x0)
#define AFIO_PIN_REMAP_CTL_UART2_MASK   1
#define AFIO_PIN_REMAP_CTL_UART2_SHIFT  3
#define AFIO_PIN_REMAP_CTL_UART2        0
#define AFIO_PIN_REMAP_CTL_TIMER2_MASK  0x3
#define AFIO_PIN_REMAP_CTL_TIMER2_SHIFT 8
#define AFIO_PIN_REMAP_CTL_TIMER2       2

#define AFIO_GPIOA_FUNC_SEL       (AFIO_BASE_ADDR + 0x80)
#define AFIO_GPIOA_SEL_BITS_MASK  0x3
#define AFIO_GPIOA_UART2_TX_SHIFT 0x4
#define AFIO_GPIOA_UART2_RX_SHIFT 0x6
#define AFIO_GPIOA_UART2_TX_SEL   0x1
#define AFIO_GPIOA_UART2_RX_SEL   0x1

void    uart_init(USART_TypeDef *port, uint8_t parity, uint8_t stop_bits, uint8_t data_bits, uint32_t bd);
void    debug(char *fmt, ...);
void    uart_putc(USART_TypeDef *port, uint8_t c);
void    uart_wait_xmit(USART_TypeDef *port);
uint8_t uart_getc(USART_TypeDef *port);
int     uart_getSingleChar(USART_TypeDef *port);
void    debug_test(void);
void    sys_io_init(void);
void    pll_init(void);
void init_uart_prn(int intDiv, int fracDiv, int dl);

void init_uart_prn(int intDiv, int fracDiv, int dl);


#define  UART_RBR            (0x0 << 2)
#define  UART_THR            (0x0 << 2)
#define  UART_DLL            (0x0 << 2)
#define  UART_IER            (0x1 << 2)
#define  UART_DLH            (0x1 << 2)
#define  UART_IIR            (0x2 << 2)
#define  UART_FCR            (0x2 << 2)
#define  UART_LCR            (0x3 << 2)
#define  UART_MCR            (0x4 << 2)
#define  UART_LSR            (0x5 << 2)
#define  UART_MSR            (0x6 << 2)
#define  UART_SCR            (0x7 << 2)
#define  UART_LPDLL          (0x8 << 2)
#define  UART_LPDLH          (0x9 << 2)
#define  UART_SRBR_LOW       (0xc << 2)
#define  UART_SRBR_HIGH      (0x1b << 2)
#define  UART_STHR_LOW       (0xc << 2)
#define  UART_STHR_HIGH      (0x1b << 2)
#define  UART_FAR            (0x1c << 2)
#define  UART_TFR            (0x1d << 2)
#define  UART_RFW            (0x1e << 2)
#define  UART_USR            (0x1f << 2)
#define  UART_TFL            (0x20 << 2)
#define  UART_RFL            (0x21 << 2)
#define  UART_SRR            (0x22 << 2)
#define  UART_SRTS           (0x23 << 2)
#define  UART_SBCR           (0x24 << 2)
#define  UART_SDMAM          (0x25 << 2)
#define  UART_SFE            (0x26 << 2)
#define  UART_SRT            (0x27 << 2)
#define  UART_STET           (0x28 << 2)
#define  UART_HTX            (0x29 << 2)
#define  UART_DMASA          (0x2a << 2)

#define  UART_DLF            (0x30 << 2)

#define  UART_RAR            (0x31 << 2)
#define  UART_TAR            (0x32 << 2)
#define  UART_LCR_EXT        (0x33 << 2)

#define  UART_CPR            (0x3d << 2)
#define  UART_UCV             (0x3e << 2)
#define  UART_CTR            (0x3f << 2)
#define  RCC_PLL_CONFIG        0x0
#define  RCC_RC32K_CONFIG      0x4
#define  RCC_RC8M_CONFIG       0x8
#define  RCC_RC8M_TRIM_CONFIG  0xc
#define  RCC_CLK_CONFIG        0x10
#define  RCC_AHB_CLKEN         0x14
#define  RCC_APB_CLKEN         0x18
#define  RCC_RC8M_TRIM_OUT     0x1c
#define  RCC_OSC32K_CTRL       0x20
#define  RCC_OSC_CTRL          0x24
//

#define  RCC_APB_SRST          0x30
#define  RCC_AHB_SRST          0x34
#define  RCC_BOOT_MODE         0x40
#define  RCC_GLB_SW_RESET      0x44
#define  RCC_MCU_RESET_STATUS  0x48
#define  RCC_INT               0x4c
#define  RCC_DMA_HS_SEL        0x60
#define  RCC_HPROT_USB         0x64
#define  RCC_USBPHY_CFG        0x68
#define  RCC_USBPHY_CTRL       0x6c
#define  RCC_SW_AUX0           0x80
#define  RCC_SW_AUX1           0x84
#define  RCC_SW_AUX2           0x88
#define  RCC_SW_AUX3           0x8c

#define REG8(x)  (*((volatile unsigned char *)(x)))
#define REG16(x) (*((volatile unsigned short *)(x)))
#define REG32(x) (*((volatile unsigned int *)(x)))

#endif
