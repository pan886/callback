/**
 * @file aip32rv15xx_can.h
 * @brief  This file contains all the functions prototypes for the CAN firmware library. 
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-06-20
 * @copyright Copyright (c) 2024 I-core, Inc
 */
#ifndef AiP32RV15A8_CAN_H
#define AiP32RV15A8_CAN_H

#include "aip32rv15xx.h"

#define CAN_Mode_Normal ((uint8_t)0x00) /**< normal mode.*/
#define CAN_Mode_listen ((uint8_t)0x02) /**< listen only mode.*/
#define CAN_Mode_Reset  ((uint8_t)0x04) /**< reset mode.*/

#define CAN_Id_Standard ((uint32_t)0x00000000) /**< Standard Id */
#define CAN_Id_Extended ((uint32_t)0x00000080) /**< Extended Id */

#define CAN_RTR_Data   ((uint32_t)0x00000000) /**< Data frame */
#define CAN_RTR_Remote ((uint32_t)0x00000040) /**< Remote frame */

#define CAN_FilterMode_Single ((uint8_t)0x00) /**< Single mode */
#define CAN_FilterMode_Dual   ((uint8_t)0x01) /**< Dual mode */

#define CAN_SJW_1tq ((uint8_t)0x00) /**< 1 time quantum */
#define CAN_SJW_2tq ((uint8_t)0x01) /**< 2 time quantum */
#define CAN_SJW_3tq ((uint8_t)0x02) /**< 3 time quantum */
#define CAN_SJW_4tq ((uint8_t)0x03) /**< 4 time quantum */

#define CAN_BS1_1tq  ((uint8_t)0x00) /**< 1 time quantum */
#define CAN_BS1_2tq  ((uint8_t)0x01) /**< 2 time quantum */
#define CAN_BS1_3tq  ((uint8_t)0x02) /**< 3 time quantum */
#define CAN_BS1_4tq  ((uint8_t)0x03) /**< 4 time quantum */
#define CAN_BS1_5tq  ((uint8_t)0x04) /**< 5 time quantum */
#define CAN_BS1_6tq  ((uint8_t)0x05) /**< 6 time quantum */
#define CAN_BS1_7tq  ((uint8_t)0x06) /**< 7 time quantum */
#define CAN_BS1_8tq  ((uint8_t)0x07) /**< 8 time quantum */
#define CAN_BS1_9tq  ((uint8_t)0x08) /**< 9 time quantum */
#define CAN_BS1_10tq ((uint8_t)0x09) /**< 10 time quantum */
#define CAN_BS1_11tq ((uint8_t)0x0A) /**< 11 time quantum */
#define CAN_BS1_12tq ((uint8_t)0x0B) /**< 12 time quantum */
#define CAN_BS1_13tq ((uint8_t)0x0C) /**< 13 time quantum */
#define CAN_BS1_14tq ((uint8_t)0x0D) /**< 14 time quantum */
#define CAN_BS1_15tq ((uint8_t)0x0E) /**< 15 time quantum */
#define CAN_BS1_16tq ((uint8_t)0x0F) /**< 16 time quantum */

#define CAN_BS2_1tq ((uint8_t)0x00) /**< 1 time quantum */
#define CAN_BS2_2tq ((uint8_t)0x01) /**< 2 time quantum */
#define CAN_BS2_3tq ((uint8_t)0x02) /**< 3 time quantum */
#define CAN_BS2_4tq ((uint8_t)0x03) /**< 4 time quantum */
#define CAN_BS2_5tq ((uint8_t)0x04) /**< 5 time quantum */
#define CAN_BS2_6tq ((uint8_t)0x05) /**< 6 time quantum */
#define CAN_BS2_7tq ((uint8_t)0x06) /**< 7 time quantum */
#define CAN_BS2_8tq ((uint8_t)0x07) /**< 8 time quantum */

#define CAN_IT_DOI ((uint8_t)0x01) /**< Data Overrun Interrupt */
#define CAN_IT_BEI ((uint8_t)0x02) /**< Buss Error Interrupt */
#define CAN_IT_TI  ((uint8_t)0x04) /**< Transmission Interrupt */
#define CAN_IT_RI  ((uint8_t)0x08) /**< Receive Interrupt */
#define CAN_IT_EPI ((uint8_t)0x10) /**< Error Passive Interrupt*/
#define CAN_IT_EWI ((uint8_t)0x20) /**< Error Warning Interrupt*/
#define CAN_IT_ALI ((uint8_t)0x40) /**< Arbitration Lost Interrupt */

#define CAN_BS  ((uint8_t)0x01) /**< bus off flag. */
#define CAN_ES  ((uint8_t)0x02) /**< Error flag */
#define CAN_TS  ((uint8_t)0x04) /**< Transmit flag*/
#define CAN_RS  ((uint8_t)0x08) /**< Receive flag*/
#define CAN_TBS ((uint8_t)0x20) /**< Transmit Buffer flag. */
#define CAN_DSO ((uint8_t)0x40) /**< Data Overrun flag.*/
#define CAN_RBS ((uint8_t)0x80) /**< Receive Buffer flag.*/

#define CAN_ErrorCode_NoErr    ((uint8_t)0x00) /**< No Error */
#define CAN_ErrorCode_BitErr   ((uint8_t)0x01) /**< Bit  Error */
#define CAN_ErrorCode_StuffErr ((uint8_t)0x02) /**< Stuff Error */
#define CAN_ErrorCode_CRCErr   ((uint8_t)0x04) /**< CRC Error  */
#define CAN_ErrorCode_FormErr  ((uint8_t)0x08) /**< Form Error */
#define CAN_ErrorCode_ACKErr   ((uint8_t)0x10) /**< Acknowledgment Error */

#define CAN_ErrorCode_TXWRN ((uint8_t)0x50) /**< set when TXERR counter is greater than or equal to 96 */

#define CAN_ErrorCode_RXWRN ((uint8_t)0x70) /**< set when RXERR counter is greater than or equal to 96 */

/**
 * @brief CAN Init structure definition. 
 */
typedef struct
{
    uint8_t         CAN_Mode; /**< set the operation mode for CAN controller.*/
    uint16_t        CAN_Prescaler;/**< /*!< Specifies the length of a time quantum. */
    uint8_t         CAN_SJW;  /**< Synchronization Jump Width.*/
    uint8_t         CAN_BS1;  /**< Specifies the number of time quanta in Bit Segment 1. */
    uint8_t         CAN_BS2;  /**< Specifies the number of time quanta in Bit Segment 2. */
    uint8_t         CAN_SAM;  /**< the Number of bus level samples.*/
    FunctionalState CAN_NART; /**< Enable or disable the no-automatic retransmission mode.*/
} CAN_InitTypeDef;

/**
 * @brief CAN transmit structure definition. 
 */
typedef struct
{
    uint32_t StdId;   /**< Specifies the standard identifier.*/
    uint32_t ExtId;   /**< Specifies the extended identifier.*/
    uint8_t  IDE;     /**< Specifies the type of identifier for the message that 
                        will be transmitted.*/
    uint8_t  RTR;     /**< Specifies the type of frame for the message that will 
                        be transmitted.*/
    uint8_t  DLC;     /**< Specifies the length of the frame that will be 
                        transmitted.*/
    uint8_t  Data[8]; /**< Contains the data to be transmitted.*/
} CanTxMsg;

/**
 * @brief CAN receive structure definition. 
 */
typedef struct
{
    uint32_t StdId; /**< Specifies the standard identifier.
                        This parameter can be a value between 0 to 0x7FF. */

    uint32_t ExtId; /**< Specifies the extended identifier.
                        This parameter can be a value between 0 to 0x1FFFFFFF. */

    uint8_t IDE; /**< Specifies the type of identifier for the message that 
                        will be received. This parameter can be a value of 
                        @ref CAN_identifier_type */

    uint8_t RTR; /**< Specifies the type of frame for the received message.
                        This parameter can be a value of 
                        @ref CAN_remote_transmission_request */

    uint8_t DLC; /**< Specifies the length of the frame that will be received.
                        This parameter can be a value between 0 to 8 */

    uint8_t Data[8]; /**< Contains the data to be received. It ranges from 0 to 
                        0xFF. */
} CanRxMsg;

/**
 * @brief CAN filter structure definition. 
 */
typedef struct
{
    uint32_t CAN_FilterId; /**< Specifies the filter identification number */

    uint16_t CAN_FilterMaskId; /**< Specifies the filter mask number or identification number */

    uint8_t CAN_FilterMode; /**< Specifies the filter mode to be initialized.
                                              This parameter can be a value of CAN_filter_mode */

    uint16_t CAN_FilterData; /**< Specifies the filter data. */

} CAN_FilterInitTypeDef;

/**
 * @brief  Function used to set the CAN configuration to the default reset state.
 */
void CAN_DeInit(void);

/**
 * @brief Initialization and Configuration functions
 * @param[in] CAN_InitStruct :pointer to a CAN_InitTypeDef structure that contains the configuration information for the  CAN peripheral.
 */
void CAN_Init(CAN_InitTypeDef *CAN_InitStruct);

/**
 * @brief Set the operation mode for CAN controller the mode of CAN.
 * @param[in] CAN_Mode:the operation mode.
 */
void CAN_Mode_Set(uint8_t CAN_Mode);

/**
 * @brief Initializes the CAN peripheral according to the specified parameters in the CAN_InitStruct.
 * @param[in] CAN_InitStruct :pointer to a CAN_InitTypeDef structure that contains the configuration information 
 * for the CAN peripheral.
 */
void CAN_StructInit(CAN_InitTypeDef *CAN_InitStruct);

/**
 * @brief Initiates the transmission of a message.
 * @param[in] TxMessage  pointer to a structure which contains CAN Id, CAN DLC and CAN data.
 */
void CAN_Transmit(CanTxMsg *TxMessage);




/**
 * @brief receive the can message.
 * @param[in] RxMessage
 */
void CAN_Receive(CanRxMsg *RxMessage);

/**
 * @brief Checks whether the specified CAN flag is set or not.
 * @param[in] CAN_FLAG specifies the flag to check.
 * @return FlagStatus  
 */
FlagStatus CAN_GetFlagStatus(uint32_t CAN_FLAG);

/**
 * @brief  Checks whether the CAN interrupt has occurred or not.
 * @param[in] It_Bit  specifies the interrupt source bit to check.
 * @return ITStatus  The new state of the CAN Interrupt (SET or RESET).
 */
static ITStatus CheckITStatus(uint32_t It_Bit);

/**
 * @brief  Checks whether the specified CANx interrupt has occurred or not.
 * @param[in] CAN_IT  specifies the CAN interrupt source to check.
 * @return ITStatus  The current state of CAN_IT (SET or RESET).
 */
ITStatus CAN_GetITStatus(uint32_t CAN_IT);

/**
 * @brief  Clears the CANx's interrupt pending bits.
 * @param[in] CAN_IT specifies the interrupt pending bit to clear.
 */
void CAN_ClearITPendingBit(uint32_t CAN_IT);

/**
 * @brief Enables or disables the specified CANx interrupts.
 * @param[in] CAN_IT specifies the CAN interrupt sources to be enabled or disabled.
 * @param[in] NewState new state of the CAN interrupts.This parameter can be: ENABLE or DISABLE.
 */
void CAN_ITConfig(uint32_t CAN_IT, FunctionalState NewState);

/**
 * @brief  Initializes the CAN peripheral according to the specified parameters in the CAN_FilterInitStruct.
 * @param[in] CAN_FilterInitStruct pointer to a CAN_FilterInitTypeDef structure that contains the configuration information.
 */
void CAN_FilterInit(CAN_FilterInitTypeDef *CAN_FilterInitStruct);

/**
 * @brief Returns the CAN Receive Error Counter (REC).
 * @return uint8_t   CAN Receive Error Counter. 
 */
uint8_t CAN_GetReceiveErrorCounter(void);

/**
 * @brief Returns the CAN Transmit Error Counter(TEC).
 * @return uint8_t  CAN Transmit Error Counter. 
 */
uint8_t CAN_GetTransmitErrorCounter(void);

/**
 * @brief Returns the CANx's last error code (LEC).
 * @return uint8_t  specifies the Error code.
 */
uint8_t CAN_GetLastErrorCode(void);

/**
 * @brief  Fills each CAN_InitStruct member with its default value.
 * @param[in] CAN_InitStruct pointer to a CAN_InitTypeDef structure which will be initialized.
 */
void CAN_StructInit(CAN_InitTypeDef *CAN_InitStruct);

#endif
