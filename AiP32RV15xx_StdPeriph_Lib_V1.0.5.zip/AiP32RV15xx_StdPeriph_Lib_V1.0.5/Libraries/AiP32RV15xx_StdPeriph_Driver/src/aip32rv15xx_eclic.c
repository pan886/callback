/*
 * @file aip32rv15xx_eclic.c
 * @brief This file provides all the eclic firmware functions.
 * @author MCD Application Team.
 * @version 1.0
 * @date 2024-05-16
 * @copyright Copyright (c) 2024 I-core, Inc.
 */

#include "aip32rv15xx_eclic.h"


/* ToDo: set the defines according your Device */
/* ToDo: define the correct core revision */
//#define __i-CORE_N_REV  0x0100     /*!< Core Revision r1p0 */

/* ToDo: define the correct core features for the i-CORE_soc */
#define __ECLIC_PRESENT 1 /*!< Set to 1 if ECLIC is present */
#define __ECLIC_BASEADDR                                                       \
  0xE0020000UL /*!< Set to ECLIC baseaddr of your device */
//
//#define __ECLIC_INTCTLBITS                                                     \
//  4 /*!< Set to 1 - 8, the number of hardware bits are actually implemented in \
//       the clicintctl registers. */
#define __ECLIC_INTNUM                                                         \
  86 /*!< Set to 1 - 1005, the external interrupt number of ECLIC Unit */
#define __SYSTIMER_PRESENT 1 /*!< Set to 1 if System Timer is present */
#define __SYSTIMER_BASEADDR                                                    \
  0xE0030000UL /*!< Set to SysTimer baseaddr of your device */


#define MAX_SYSTEM_EXCEPTION_NUM 12
static unsigned long SystemExceptionHandlers[MAX_SYSTEM_EXCEPTION_NUM + 1];
typedef void (*EXC_HANDLER)(unsigned long mcause, unsigned long sp);
static void system_default_exception_handler(unsigned long mcause,
                                             unsigned long sp) {
  /* TODO: Uncomment this if you have implement printf function */

  while (1)
    ;
}
static void Exception_Init(void) {
  for (int i = 0; i < MAX_SYSTEM_EXCEPTION_NUM + 1; i++) {
    SystemExceptionHandlers[i] =
        (unsigned long)system_default_exception_handler;
  }
}
void ECLIC_Init(void) {
  /* TODO: Add your own initialization code here. This function will be called
   * by main */
  ECLIC_SetMth(0);
  ECLIC_SetCfgNlbits(__ECLIC_INTCTLBITS);
}

uint32_t core_exception_handler(unsigned long mcause, unsigned long sp) {
  uint32_t EXCn = (uint32_t)(mcause & 0X00000fff);
  EXC_HANDLER exc_handler;

  if (EXCn < MAX_SYSTEM_EXCEPTION_NUM) {
    exc_handler = (EXC_HANDLER)SystemExceptionHandlers[EXCn];
  } else if (EXCn == NMI_EXCn) {
    exc_handler =
        (EXC_HANDLER)SystemExceptionHandlers[MAX_SYSTEM_EXCEPTION_NUM];
  } else {
    exc_handler = (EXC_HANDLER)system_default_exception_handler;
  }
  if (exc_handler != NULL) {
    exc_handler(mcause, sp);
  }
  return 0;
}


/**
 * \brief       Register an exception handler for exception code EXCn
 * \details
 * * For EXCn < \ref MAX_SYSTEM_EXCEPTION_NUM, it will be registered into SystemExceptionHandlers[EXCn-1].
 * * For EXCn == NMI_EXCn, it will be registered into SystemExceptionHandlers[MAX_SYSTEM_EXCEPTION_NUM].
 * \param   EXCn    See \ref EXCn_Type
 * \param   exc_handler     The exception handler for this exception code EXCn
 */
void Exception_Register_EXC(uint32_t EXCn, unsigned long exc_handler)
{
    if (EXCn < MAX_SYSTEM_EXCEPTION_NUM) {
        SystemExceptionHandlers[EXCn] = exc_handler;
    } else if (EXCn == NMI_EXCn) {
        SystemExceptionHandlers[MAX_SYSTEM_EXCEPTION_NUM] = exc_handler;
    }
}



void _premain_init(void) {

  /* Initialize exception default handlers */
  Exception_Init();
  /* ECLIC initialization, mainly MTH and NLBIT */
  ECLIC_Init();
}

/**
 * \brief  Initialize a specific IRQ and register the handler
 * \details
 * This function set vector mode, trigger mode and polarity, interrupt level and
 * priority, assign handler for specific IRQn. \param [in]  IRQn        NMI
 * interrupt handler address \param [in]  shv         \ref
 * ECLIC_NON_VECTOR_INTERRUPT means non-vector mode, and \ref
 * ECLIC_VECTOR_INTERRUPT is vector mode \param [in]  trig_mode   see \ref
 * ECLIC_TRIGGER_Type \param [in]  lvl         interupt level \param [in]
 * priority    interrupt priority \param [in]  handler     interrupt handler, if
 * NULL, handler will not be installed \return       -1 means invalid input
 * parameter. 0 means successful. \remarks
 * - This function use to configure specific eclic interrupt and register its
 * interrupt handler and enable its interrupt.
 * - If the vector table is placed in read-only section(FLASHXIP mode), handler
 * could not be installed
 */
int32_t ECLIC_Register_IRQ(IRQn_Type IRQn, uint8_t shv,
                           ECLIC_TRIGGER_Type trig_mode, uint8_t lvl,
                           uint8_t priority, void *handler) {
  if ((IRQn > SOC_INT_MAX) || (shv > ECLIC_VECTOR_INTERRUPT) ||
      (trig_mode > ECLIC_NEGTIVE_EDGE_TRIGGER)) {
    return -1;
  }

  /* set interrupt vector mode */
  ECLIC_SetShvIRQ(IRQn, shv);
  /* set interrupt trigger mode and polarity */
  ECLIC_SetTrigIRQ(IRQn, trig_mode);
  /* set interrupt level */
  ECLIC_SetLevelIRQ(IRQn, lvl);
  /* set interrupt priority */
  ECLIC_SetPriorityIRQ(IRQn, priority);
  if (handler != NULL) {
    /* set interrupt handler entry to vector table */
    ECLIC_SetVector(IRQn, (rv_csr_t)handler);
  }
  /* enable interrupt */
  ECLIC_EnableIRQ(IRQn);
  return 0;
}
