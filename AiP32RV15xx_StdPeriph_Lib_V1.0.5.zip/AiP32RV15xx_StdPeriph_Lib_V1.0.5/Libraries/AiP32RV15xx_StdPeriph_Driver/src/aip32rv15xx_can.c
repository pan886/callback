/**
 * @file aip32rv15xx_can.c
 * @brief This file provides all the CAN firmware functions.
 * @author MCD Application Team.
 * @version 1.0
 * @date 2022-06-15
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "aip32rv15xx_can.h"

#define IS_CAN_MODE(MODE) (((MODE) == CAN_Mode_Normal) || \
                           ((MODE) == CAN_Mode_listen) || \
                           ((MODE) == CAN_Mode_Reset))

#define IS_CAN_IDTYPE(IDTYPE) (((IDTYPE) == CAN_Id_Standard) || \
                               ((IDTYPE) == CAN_Id_Extended))

#define IS_CAN_RTR(RTR) (((RTR) == CAN_RTR_Data) || ((RTR) == CAN_RTR_Remote))

#define IS_CAN_SJW(SJW) (((SJW) == CAN_SJW_1tq) || ((SJW) == CAN_SJW_2tq) || \
                         ((SJW) == CAN_SJW_3tq) || ((SJW) == CAN_SJW_4tq))

#define IS_CAN_BS1(BS1) ((BS1) <= CAN_BS1_16tq)

#define IS_CAN_BS2(BS2) ((BS2) <= CAN_BS2_8tq)

#define IS_CAN_STDID(STDID) ((STDID) <= ((uint32_t)0x7FF))
#define IS_CAN_EXTID(EXTID) ((EXTID) <= ((uint32_t)0x1FFFFFFF))

void CAN_DeInit()
{
    /* Enable CAN1 reset state */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN, ENABLE);
    /* Release CAN1 from reset state */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN, DISABLE);
}

void CAN_Init(CAN_InitTypeDef *CAN_InitStruct)
{

    /*reset mode*/
    CAN_Mode_Set(CAN_Mode_Reset);

    /* Set the bit timing register */
    CAN->BTR1_BTR0_RMC_IMR.value |= (CAN_InitStruct->CAN_Prescaler << 16) | (CAN_InitStruct->CAN_SJW << 22) |
                                    (CAN_InitStruct->CAN_BS1 << 24) | (CAN_InitStruct->CAN_BS2 << 28) |
                                    (CAN_InitStruct->CAN_SAM << 31);
    CAN_Mode_Set(CAN_Mode_Normal);

}

void CAN_Mode_Set(uint8_t CAN_Mode)
{

    switch (CAN_Mode) {
    case CAN_Mode_Reset:
        CAN->MR.value = CAN_Mode_Reset;
        break;
    case CAN_Mode_Normal:
    	CAN->MR.value  = CAN_Mode_Normal;
        break;
    case CAN_Mode_listen:
        CAN->MR.value = CAN_Mode_listen;
        break;
    default:
        break;
    }
}

void CAN_StructInit(CAN_InitTypeDef *CAN_InitStruct)
{
    /* Initialize the CAN_Mode member */
    CAN_InitStruct->CAN_Mode = CAN_Mode_Normal;

    /* Initialize the CAN_SJW member */
    CAN_InitStruct->CAN_SJW = CAN_SJW_1tq;

    /* Initialize the CAN_BS1 member */
    CAN_InitStruct->CAN_BS1 = CAN_BS1_4tq;

    /* Initialize the CAN_BS2 member */
    CAN_InitStruct->CAN_BS2 = CAN_BS2_3tq;

    /* Initialize the CAN_Prescaler member */
    CAN_InitStruct->CAN_Prescaler = 1;
}

void CAN_Transmit(CanTxMsg *TxMessage)
{

    if (TxMessage->IDE == CAN_Id_Standard) {
        assert_param(IS_CAN_STDID(TxMessage->StdId));
        /* Set up the Id RTR DLC data 1*/
        CAN->TXBUF |= ((TxMessage->StdId & 0x7) << 21 | (TxMessage->StdId & 0x7F8) << 5) | TxMessage->RTR | TxMessage->DLC | TxMessage->Data[0] << 24;
        /* Set up the data field */
        CAN->TXBUF |= TxMessage->Data[1] | TxMessage->Data[2] << 8 | TxMessage->Data[3] << 16 | TxMessage->Data[4] << 24;
        CAN->TXBUF |= TxMessage->Data[5] | TxMessage->Data[6] << 8 | TxMessage->Data[7] << 16;
    } else {
        assert_param(IS_CAN_EXTID(TxMessage->ExtId));
        /* Set up the Id RTR DLC */
        CAN->TXBUF |= (TxMessage->ExtId & 0x1fe0) << 19 | (TxMessage->ExtId & 0x1fe000) << 3 | (TxMessage->ExtId & 0x1FE00000) >> 13 | TxMessage->IDE |
                      TxMessage->RTR | TxMessage->DLC;
        /* Set up the data field */
        CAN->TXBUF |= (TxMessage->ExtId & 0x1f) << 3 | TxMessage->Data[0] << 8 | TxMessage->Data[1] << 16 | TxMessage->Data[2] << 24;
        CAN->TXBUF |= TxMessage->Data[3] | TxMessage->Data[4] << 8 | TxMessage->Data[5] << 16 | TxMessage->Data[6] << 24;
        CAN->TXBUF |= TxMessage->Data[7];
    }

    if (CAN->STATUS.TBS == 0x1) {
        CAN->CMR.value = 0x6;
    }
}

void CAN_Receive(CanRxMsg *RxMessage)
{
    int      i        = 0;
    uint32_t offset_0 = 0;
    uint32_t offset_1 = 0;
    uint32_t offset_2 = 0;
    uint32_t offset_3 = 0;
    offset_0          = CAN->RXBUF;
    offset_1          = CAN->RXBUF;
    offset_2          = CAN->RXBUF;
    RxMessage->IDE    = offset_0 & 0x80;
    if (RxMessage->IDE != CAN_Id_Standard)
        offset_3 = CAN->RXBUF;

    /* Get the DLC */
    RxMessage->DLC = offset_0 & 0xf;
    /* Get the Id */
    if (RxMessage->IDE == CAN_Id_Standard) {
        RxMessage->StdId = ((offset_0 & 0xE00000) >> 21) | ((offset_0 & 0xff00) >> 5);
        debug("StdId = %x\n", RxMessage->StdId);

        /* Get the data field */
        RxMessage->RTR = (offset_0 & 0x40) >> 6;
        debug("RTR = %x\n", RxMessage->RTR);
        switch (RxMessage->DLC) {
        case 1:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            break;
        case 2:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            break;
        case 3:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            break;
        case 4:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[3] = (offset_1 & 0xff0000) >> 16;

            break;
        case 5:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[3] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[4] = (offset_1 & 0xff000000) >> 24;
            break;
        case 6:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[3] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[4] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[5] = offset_2 & 0xff;
            break;
        case 7:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[3] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[4] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[5] = offset_2 & 0xff;
            RxMessage->Data[6] = (offset_2 & 0xff00) >> 8;
            break;
        case 8:
            RxMessage->Data[0] = (offset_0 & 0xFF000000) >> 24;
            RxMessage->Data[1] = (offset_1 & 0xff);
            RxMessage->Data[2] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[3] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[4] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[5] = offset_2 & 0xff;
            RxMessage->Data[6] = (offset_2 & 0xff00) >> 8;
            RxMessage->Data[7] = (offset_2 & 0xff0000) >> 16;
            break;
        }
        for (i = 0; i < RxMessage->DLC; i++)
            debug("%x\n", RxMessage->Data[i]);

    } else {

        RxMessage->ExtId = ((offset_0 & 0xFF000000) >> 19) | ((offset_0 & 0xFF0000) >> 3 |
                                                              ((offset_0 & 0xFF00) << 13) | ((offset_1 & 0xf8) >> 3));
        debug("ExtId = %x\n", RxMessage->ExtId);
        switch (RxMessage->DLC) {
        case 1:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            break;
        case 2:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            break;
        case 3:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            break;
        case 4:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[3] = offset_2 & 0xff;
            break;
        case 5:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[3] = offset_2 & 0xff;
            RxMessage->Data[4] = (offset_2 & 0xff00) >> 8;
            break;
        case 6:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[3] = offset_2 & 0xff;
            RxMessage->Data[4] = (offset_2 & 0xff00) >> 8;
            RxMessage->Data[5] = (offset_2 & 0xff0000) >> 16;
            break;
        case 7:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[3] = offset_2 & 0xff;
            RxMessage->Data[4] = (offset_2 & 0xff00) >> 8;
            RxMessage->Data[5] = (offset_2 & 0xff0000) >> 16;
            RxMessage->Data[6] = (offset_2 & 0xff000000) >> 24;
            break;
        case 8:
            RxMessage->Data[0] = (offset_1 & 0xff00) >> 8;
            RxMessage->Data[1] = (offset_1 & 0xff0000) >> 16;
            RxMessage->Data[2] = (offset_1 & 0xff000000) >> 24;
            RxMessage->Data[3] = offset_2 & 0xff;
            RxMessage->Data[4] = (offset_2 & 0xff00) >> 8;
            RxMessage->Data[5] = (offset_2 & 0xff0000) >> 16;
            RxMessage->Data[6] = (offset_2 & 0xff000000) >> 24;
            RxMessage->Data[7] = offset_3 & 0xff;
            break;
        }

        for (i = 0; i < RxMessage->DLC; i++)
            debug("%x\n", RxMessage->Data[i]);
    }

    debug("DLC = %x\n", RxMessage->DLC);
}

FlagStatus CAN_GetFlagStatus(uint32_t CAN_FLAG)
{
    FlagStatus bitstatus = RESET;

    /* Check the parameters */
    assert_param(IS_CAN_GET_FLAG(CAN_FLAG));
    if (CAN_FLAG == CAN_BS) {
        if (CAN->STATUS.BS == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }
    if (CAN_FLAG == CAN_DSO) {
        if (CAN->STATUS.DSO == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }
    if (CAN_FLAG == CAN_ES) {
        if (CAN->STATUS.ES == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }

    if (CAN_FLAG == CAN_TS) {
        if (CAN->STATUS.TS == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }

    if (CAN_FLAG == CAN_RS) {
        if (CAN->STATUS.RS == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }

    if (CAN_FLAG == CAN_RBS) {
        if (CAN->STATUS.RBS == SET) {
            /* CAN_FLAG is set */
            bitstatus = SET;
        } else {
            /* CAN_FLAG is reset */
            bitstatus = RESET;
        }
    }

    /* Return the CAN_FLAG status */
    return bitstatus;
}

static ITStatus CheckITStatus(uint32_t It_Bit)
{
    ITStatus pendingbitstatus = RESET;

    if ((CAN->ISR.value & It_Bit) != (uint32_t)RESET) {
        /* CAN_IT is set */
        pendingbitstatus = SET;
    } else {
        /* CAN_IT is reset */
        pendingbitstatus = RESET;
    }
    return pendingbitstatus;
}

ITStatus CAN_GetITStatus(uint32_t CAN_IT)
{
    ITStatus itstatus = RESET;
   // assert_param(IS_CAN_IT(CAN_IT));

    /* check the enable interrupt bit */
    if ((CAN->ISR.value & CAN_IT) != RESET) {
        switch (CAN_IT) {
        case CAN_IT_DOI:
            itstatus = CheckITStatus(CAN_IT_DOI);
            break;
        case CAN_IT_BEI:
            itstatus = CheckITStatus(CAN_IT_BEI);
            break;
        case CAN_IT_TI:
            itstatus = CheckITStatus(CAN_IT_TI);
            break;
        case CAN_IT_RI:
            itstatus = CheckITStatus(CAN_IT_RI);
            break;
        case CAN_IT_EPI:
            itstatus = CheckITStatus(CAN_IT_EPI);
            break;
        case CAN_IT_EWI:
            itstatus = CheckITStatus(CAN_IT_EWI);
            break;
        case CAN_IT_ALI:
            itstatus = CheckITStatus(CAN_IT_ALI);
            break;
        default:
            break;
        }
    } else {
        /* in case the Interrupt is not enabled, return RESET */
        itstatus = RESET;
    }

    /* Return the CAN_IT status */
    return itstatus;
}

void CAN_ClearITPendingBit(uint32_t CAN_IT)
{

    /* Check the parameters */
    assert_param(IS_CAN_CLEAR_IT(CAN_IT));

    switch (CAN_IT) {
    case CAN_IT_DOI:
        CAN->ISR.DOI = 0x1;
        break;
    case CAN_IT_TI:
        CAN->ISR.TI = 0x1;
        break;
    case CAN_IT_RI:
        CAN->ISR.RI = 0x1;
        break;
    case CAN_IT_EPI:
        CAN->ISR.EPI = 0x1;
        break;
    case CAN_IT_EWI:
        CAN->ISR.EWI = 0x1;
        break;
    case CAN_IT_ALI:
        CAN->ISR.ALI = 0x1;
        break;
    default:
        break;
    }
}

void CAN_ITConfig(uint32_t CAN_IT, FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_CAN_IT(CAN_IT));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState != DISABLE) {
        /* Enable the selected CANx interrupt */
        CAN->BTR1_BTR0_RMC_IMR.IMR |= CAN_IT;
    } else {
        /* Disable the selected CANx interrupt */
        CAN->BTR1_BTR0_RMC_IMR.IMR &= ~CAN_IT;
    }
}

void CAN_FilterInit(CAN_FilterInitTypeDef *CAN_FilterInitStruct)
{
    CAN_Mode_Set(CAN_Mode_Reset);
    if (CAN_FilterInitStruct->CAN_FilterMode == CAN_FilterMode_Single) {
        CAN->MR.AFM = 0x1;
        if (CAN_FilterInitStruct->CAN_FilterId <= 0x7ff) {
            CAN->ACR = (CAN_FilterInitStruct->CAN_FilterId & 0x7f8) >> 3 |
                       (CAN_FilterInitStruct->CAN_FilterId & 0x7) << 13 |
                       ((CAN_FilterInitStruct->CAN_FilterData) & 0xff) << 16 |
                       ((CAN_FilterInitStruct->CAN_FilterData) & 0xff00) << 16;

            CAN->AMR.value = ((CAN_FilterInitStruct->CAN_FilterMaskId & 0x7f8) >> 3 |
                              (CAN_FilterInitStruct->CAN_FilterMaskId & 0x7) << 13);
        } else {
            CAN->ACR       = ((CAN_FilterInitStruct->CAN_FilterId & 0x1f) << 27 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1fE0) << 11 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1fE000) >> 5 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1fE00000) >> 21);
            CAN->AMR.value = 0;
            // CAN->AMR.value = ((CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE00000) >> 21 |
            //                   (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE000) >> 5 |
            //                   (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE0) << 11 |
            //                   (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1f) << 27);
        }
    } else {
        CAN->MR.AFM = 0x0;
        if (CAN_FilterInitStruct->CAN_FilterId <= 0x7ff) {
            CAN->ACR = (CAN_FilterInitStruct->CAN_FilterId & 0x7f8) >> 3 |
                       (CAN_FilterInitStruct->CAN_FilterId & 0x7) << 13 |
                       (CAN_FilterInitStruct->CAN_FilterData & 0xf0) << 4 |
                       (CAN_FilterInitStruct->CAN_FilterData & 0xf) << 24;
            CAN->AMR.value = 0;
        } else {
            CAN->ACR       = ((CAN_FilterInitStruct->CAN_FilterId & 0x1FE00000) >> 21 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1FE000) >> 13 << 8 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1FE00000) >> 5 |
                        (CAN_FilterInitStruct->CAN_FilterId & 0x1FE000) << 11);
            CAN->AMR.value = ((CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE00000) >> 21 |
                              (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE000) >> 13 << 8 |
                              (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE00000) >> 5 |
                              (CAN_FilterInitStruct->CAN_FilterMaskId & 0x1FE000) << 11);
            ;
        }
    }
    CAN_Mode_Set(CAN_Mode_Normal);
}


uint8_t CAN_GetReceiveErrorCounter()
{
    uint8_t counter = 0;

    /* Get the Receive Error Counter*/
    counter = (uint8_t)((CAN->TXERR_RXERR_ECC.value & 0xff00) >> 8);

    /* Return the Receive Error Counter*/
    return counter;
}

uint8_t CAN_GetTransmitErrorCounter()
{
    uint8_t counter = 0;

    /* Get the Transmit Error Counter*/
    counter = (uint8_t)((CAN->TXERR_RXERR_ECC.value & 0xff0000) >> 16);

    /* Return the Transmit Error Counter*/
    return counter;
}

uint8_t CAN_GetLastErrorCode()
{
    uint8_t errorcode = 0;

    /* Get the error code*/
    errorcode = (((uint8_t)CAN->TXERR_RXERR_ECC.ECC.value));

    /* Return the error code*/
    return errorcode;
}


