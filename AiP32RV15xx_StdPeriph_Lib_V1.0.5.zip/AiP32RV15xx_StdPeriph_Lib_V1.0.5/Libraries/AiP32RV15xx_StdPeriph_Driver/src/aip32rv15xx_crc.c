/**
 * @file aip32rv15xx_crc.c
 * @brief This file provides all the CRC firmware functions.
 * @author MCD Application Team.
 * @version 1.0
 * @date 2024-06-18
 * @copyright Copyright (c) 2024 Icore, Inc
 */

#include "aip32rv15xx_crc.h"


#define IS_CRC_DATA_INVOUT(INVOUT) (((INVOUT) == CRC_Reverse) || \
                                    ((INVOUT) == CRC_Not_Reverse))
#define IS_CRC_MODE(MODE) ((MODE == CRC_16) || (MODE == CRC_32))
void CRC_ResetDR(void)
{
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, DISABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, ENABLE);
}

uint32_t CRC_CalcCRC(uint32_t Data)
{
    uint32_t input_data = 0;
    input_data          = (Data & 0xff) << 24 | ((Data & 0xff00) >> 8) << 16 | ((Data & 0xff0000) >> 16) << 8 | (Data & 0xff000000) >> 24;
    CRC->CRC_IN         = input_data;

    if((CRC->CRC_CTL.INVOUT == CRC_Reverse)&&(CRC->CRC_CTL.CRC_SELECT == CRC_16) )

    	 return ((CRC->CRC_OUT))>>16;
		else

    return (CRC->CRC_OUT);
}

uint32_t CRC_GetCRC(void)
{
    return (CRC->CRC_OUT);
}

void CRC_InputControl(uint8_t invout, uint8_t crc_mode)
{
    assert_param(IS_CRC_DATA_INVOUT(invout));
    assert_param(IS_CRC_MODE(crc_mode));

    CRC->CRC_CTL.INVOUT = invout;
    if (crc_mode == CRC_16)
    {
        CRC->CRC_CTL.CRC_SELECT = 0x1;
    } else
    {
        CRC->CRC_CTL.CRC_SELECT = 0x0;
    }
   // if(invout == CRC_Reverse)

}

void CRC_SeedConfig(uint32_t value)
{
    CRC->CRCSEED.value = value;
}

void CRC_ClearValue(void)
{
	CRC->CRCSEED.value = 0;
}


uint32_t CRC_CalcBlockCRC(uint32_t pBuffer[], uint32_t BufferLength)
{
    uint32_t index = 0;
    uint32_t input = 0;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, DISABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, ENABLE);

    for (index = 0; index < BufferLength; index++)
    {
        input = (pBuffer[index] & 0xff) << 24 | ((pBuffer[index] & 0xff00) >> 8) << 16 | ((pBuffer[index] & 0xff0000) >> 16) << 8 | (pBuffer[index] & 0xff000000) >> 24;

        CRC->CRC_IN = input;
    }


    if((CRC->CRC_CTL.INVOUT == CRC_Reverse)&&(CRC->CRC_CTL.CRC_SELECT == CRC_16) )

        	 return ((CRC->CRC_OUT))>>16;
    		else

        return (CRC->CRC_OUT);

}

