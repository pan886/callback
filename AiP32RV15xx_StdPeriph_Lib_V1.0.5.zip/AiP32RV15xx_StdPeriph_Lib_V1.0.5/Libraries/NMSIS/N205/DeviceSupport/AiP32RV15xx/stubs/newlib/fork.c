/* See LICENSE of license details. */

#include <errno.h>

#undef errno
extern int errno;

 int _fork(void)
{
    errno = ENOSYS;
    return -1;
}
