/* See LICENSE of license details. */

#include <stddef.h>
#include "core_feature_base.h"
 void* __dso_handle = NULL;

 void _exit(int fd)
{
    while (1) {
        __WFI();
    }
}
