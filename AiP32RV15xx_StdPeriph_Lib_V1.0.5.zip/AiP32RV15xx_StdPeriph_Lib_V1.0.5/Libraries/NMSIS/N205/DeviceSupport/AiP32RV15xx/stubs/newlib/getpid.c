/* See LICENSE of license details. */

#include <errno.h>

 int _getpid(void)
{
    return 1;
}
