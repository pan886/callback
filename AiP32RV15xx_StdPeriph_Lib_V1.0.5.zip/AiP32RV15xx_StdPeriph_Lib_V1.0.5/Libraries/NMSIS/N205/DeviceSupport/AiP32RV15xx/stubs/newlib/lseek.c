/* See LICENSE of license details. */

#include <errno.h>



 int _lseek(int file, int offset, int whence)
{
    return 0;
}
