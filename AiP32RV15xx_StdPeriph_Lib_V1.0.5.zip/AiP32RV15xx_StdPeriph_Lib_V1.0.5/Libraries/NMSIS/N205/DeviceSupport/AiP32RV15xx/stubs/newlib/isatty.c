/* See LICENSE of license details. */

#include <unistd.h>


 int _isatty(int fd)
{
    return 1;
}
