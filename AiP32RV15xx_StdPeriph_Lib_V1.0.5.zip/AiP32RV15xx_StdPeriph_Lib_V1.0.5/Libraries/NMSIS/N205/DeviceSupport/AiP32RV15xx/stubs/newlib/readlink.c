/* See LICENSE of license details. */

#include <errno.h>
#include <sys/types.h>

#undef errno
extern int errno;

 int _readlink(const char *path, char *buf, size_t bufsize)
{
    errno = ENOSYS;
    return -1;
}
