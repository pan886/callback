
/* See LICENSE of license details. */
#include <errno.h>


 int _unlink(const char* name)
{
    return -1;
}
