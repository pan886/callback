/* See LICENSE of license details. */

#include <errno.h>
#include <sys/types.h>

#undef errno
extern int errno;

 int _symlink(const char *path1, const char *path2)
{
    errno = ENOSYS;
    return -1;
}
