#ifndef _i-CORE_SDK_SOC_H
#define _i-CORE_SDK_SOC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "../../../AiP32RV15xx/Common/Include/aip32rv15xx.h"

#ifdef __cplusplus
}
#endif
#endif
