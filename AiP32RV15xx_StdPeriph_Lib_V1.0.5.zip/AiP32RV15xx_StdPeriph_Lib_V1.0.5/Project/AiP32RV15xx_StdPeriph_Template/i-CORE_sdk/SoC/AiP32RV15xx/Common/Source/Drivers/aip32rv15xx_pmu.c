/**
 * @file aip32rv15xx_pmu.c
 * @brief This file provides all the PMU firmware functions.
 * @author MCD Application Team.
 * @version 1.0
 * @date 2022-05-13
 * @copyright Copyright (c) 2022 Icore, Inc.
 */
 
#include "aip32rv15xx_pmu.h"

#include "core_feature_eclic.h"
#include "../../../../AiP32RV15xx/Common/Include/aip32rv15xx_exti.h"
#include "../../../../AiP32RV15xx/Common/Include/aip32rv15xx_gpio.h"



#define write_csr(reg, val) ({ \
  if (__builtin_constant_p(val) && (unsigned long)(val) < 32) \
    asm volatile ("csrw " #reg ", %0" :: "i"(val)); \
  else \
    asm volatile ("csrw " #reg ", %0" :: "r"(val)); })


void enter_standby_mode()
{
    PMU->CHIP_PD_REQ = 0x1;
    __set_wfi_sleepmode(WFI_DEEP_SLEEP);
    /* Request Wait For Interrupt */
    __WFI();
}



void enter_stop_mode()
{
	write_csr(0x810, 0x1);
	write_csr(0x811, 0x1);
    __WFI();
}


void enter_sleepmode(uint8_t sleepmodecmd)
{
    /* clear sleepdeep bit of RISC-V system control register */
    __set_wfi_sleepmode(WFI_SHALLOW_SLEEP);


    /* select WFI or WFE command to enter sleep mode */
    if (WFI_CMD == sleepmodecmd)
    {
        __WFI();
    } else
    {
        __disable_irq();
        __WFE();
        __enable_irq();
    }
}




Power_State pmu_power_state()
{
    switch (PMU->CHIP_PWR_STATE)
    {
        case 0:
            return MCU_SLEEP_MODE;
        case 1:
            return POWERUP_MODE;
        case 2:
            return MCU_ACTIVE_MODE;
        case 3:
            return MCU_POWERDOWN_STATE;
        case 4:
            return MCU_STANDBY_STATE;
        default:
            return MCU_ACTIVE_MODE;
    }
}




void Pmu_config_lowpower()
{
	/*pmu 1.7V power enable control*/
	PMU->PMU_CTL0.flash_hp_pd_en_lv_reg =0x1;

	/* pmu low power mode enable.*/
	PMU->PMU_CTL0.en_lp_lv_reg =0x1;
}

wakeup_state  pmu_wakeup_state()
{
	switch(PMU->MCU_WAKEUP_SRC.MCU_WAKEUP_SRC)
	{
	case 1:
		return Wakeup_from_PA0;
	case 3:
		return Wakeup_from_RTC;
	 default:
		 return 0;
	}

}

Boot_state Pmu_get_boot_state()
{
	if(PMU->MCU_WAKEUP_SRC.MCU_BOOT_RST_SRC ==0)
		return boot_from_por_resset;
	else
		return boot_from_wakingup;
}

void PMU_PA0(PA0_pull_mode pull_mode)
{
	EXTI_InitTypeDef EXTI_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	  /* Configure PA.00 pin as input floating */
	  GPIO_StructInit(&GPIO_InitStructure);
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);

	  /* Enable AFIO clock */
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	  /* Connect EXTI0 Line to PA.00 pin */
	  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);

	  /* Configure EXTI0 line */
	  EXTI_StructInit(&EXTI_InitStructure);
	  EXTI_InitStructure.EXTI_Line = EXTI_Line0;
	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	  EXTI_Init(&EXTI_InitStructure);

	  /* Enable and set EXTI0 Interrupt to the lowest priority */
	  ECLIC_Register_IRQ(EXTI0_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
	                     ECLIC_LEVEL_TRIGGER, 2, 0, (void *)0);


	if(pull_mode == pull_down)
		PMU->PA0_AON_CTRL =0;
	else
		PMU->PA0_AON_CTRL |=0x1;
	PMU->PA0_AON_CTRL |=0x2;

	PMU->PMU_GPIO_IEN = 0x3; // GPIO PA0 interrupt enable

    PMU->PA0_AON_CTRL = 0x4; // Config GPIO PA0 as input mode
}

