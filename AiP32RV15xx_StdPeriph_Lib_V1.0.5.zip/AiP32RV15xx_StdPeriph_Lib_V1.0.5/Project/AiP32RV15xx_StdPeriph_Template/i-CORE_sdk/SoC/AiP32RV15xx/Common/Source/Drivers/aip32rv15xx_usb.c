/**
 * @file aip32rv15xx_usb.c
 * @brief This file provides all the USB firmware functions.
 * @author MCD Application Team.
 * @version 1.0
 * @date 2023-1-15
 * @copyright Copyright (c) 2023 Icore, Inc
 */
#include "aip32rv15xx.h"



#define IS_USB_EPNUM(EPNUM) (((EPNUM) == EP0) || ((EPNUM) == EP1) || ((EPNUM) == EP2) || \
                             ((EPNUM) == EP3) || ((EPNUM) == EP4) || ((EPNUM) == EP4) || \
                             ((EPNUM) == EP5) || ((EPNUM) == EP6) || ((EPNUM) == EP7))

//#define IS_USB_TRANSFER_TYPE(TYPE) (((TYPE) == HOST_TX) || ((TYPE) == HOST_RX))

#define IS_USB_Address(ADDRESS) (((ADDRESS) >= 0) && ((ADDRESS) <= 128))

#define IS_USB_NAK(NAK_INTERVAL) (((NAK_INTERVAL) >= 0) && ((NAK_INTERVAL) <= 256))

#define IS_USB_SPEED(SPEED) (((SPEED) == USB_SPEED_LOW) || ((SPEED) == USB_SPEED_FULL))

#define IS_USB_SPEED(SPEED) (((SPEED) == USB_SPEED_LOW) || ((SPEED) == USB_SPEED_FULL))

#define IS_USB_PROTOCOL(PROTOCOL) (((PROTOCOL) == CONTROL) || ((PROTOCOL) == ISOCHRONOUS) || \
                                   ((PROTOCOL) == BULK) || ((PROTOCOL) == INTERRUPT))

#define IS_USB_TRANSFER_TYPE(TYPE) ((TYPE ==1)||(TYPE ==0))

#define USB_DMA_CHANNEL_OFFSET(_bchannel, _offset) (USB_DMA_BASE + (_bchannel << 4) + _offset)

const uint8_t Usb_Test_Packet[53] = {

    /* JKJKJKJK x9 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /* JJKKJJKK x8 */
    0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa,
    /* JJJJKKKK x8 */
    0xee, 0xee, 0xee, 0xee, 0xee, 0xee, 0xee, 0xee,
    /* JJJJJJJKKKKKKK x8 */
    0xfe, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    /* JJJJJJJK x8 */
    0x7f, 0xbf, 0xdf, 0xef, 0xf7, 0xfb, 0xfd,
    /* JKKKKKKK x10, JK */
    0xfc, 0x7e, 0xbf, 0xdf, 0xef, 0xf7, 0xfb, 0xfd, 0x7e

};

void Usb_Write_Fifo(uint8_t Epnum, const uint8_t Buffer[], uint8_t Length)
{
    assert_param(IS_USB_EPNUM(Epnum));
    uint8_t i = 0;
    for (i = 0; i < Length; i++) {
        REG8(USB_BASE + MUSB_EP0_FIFO + Epnum * 4) = Buffer[i];
    }
}

uint8_t *Usb_Read_Fifo(uint8_t Epnum, uint8_t Buffer[], uint8_t Length)
{
    assert_param(IS_USB_EPNUM(Epnum));
    uint8_t i = 0;
    for (i = 0; i < Length; i++) {
        Buffer[i] = REG8(USB_BASE + MUSB_EP0_FIFO + 0x4 * Epnum);
    }
    return Buffer;
}

void Usb_Load_Testpacket()
{

    Usb_Write_Fifo(EP0, Usb_Test_Packet, sizeof(Usb_Test_Packet));
    REG8(USB_BASE + MUSB_TESTMODE)   = MUSB_TEST_PACKET | MUSB_TEST_FIFO_ACCESS | MUSB_TEST_FORCE_FS|MUSB_TEST_K;
    REG8(CONFIG_EP(EP0) + MUSB_CSR0) = MUSB_CSR0_TXPKTRDY;
}

void Usb_All_Interrupts(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {
        REG8(USB_BASE + MUSB_INTRUSBE) = 0xf7;
        REG8(USB_BASE + MUSB_INTRTXE)  = 0xff;
        REG8(USB_BASE + MUSB_INTRRXE)  = 0xfe;
    } else {
        REG8(USB_BASE + MUSB_INTRUSBE) = 0;
        REG8(USB_BASE + MUSB_INTRTXE)  = 0;
        REG8(USB_BASE + MUSB_INTRRXE)  = 0;
        REG8(USB_BASE + MUSB_INTRUSB);
        REG8(USB_BASE + MUSB_INTRTX);
        REG8(USB_BASE + MUSB_INTRRX);
    }
}

void Usb_Set_Host_Mode()
{
    REG8(USB_BASE + MUSB_INTRUSBE) |= MUSB_INTR_SOF | MUSB_INTR_CONNECT | MUSB_INTR_SESSREQ | MUSB_INTR_DISCONNECT;
    REG8(USB_BASE + MUSB_DEVCTL) = MUSB_DEVCTL_SESSION | MUSB_DEVCTL_HM;
}

void Usb_Host_Wait()
{

    while ((REG8(USB_BASE + MUSB_DEVCTL) & MUSB_DEVCTL_BDEVICE) == MUSB_DEVCTL_BDEVICE)
        ;
}

void Usb_Wait_Vbusvalid()
{
    /*Detect VBUS_VALID*/
    while ((REG8(USB_BASE + MUSB_DEVCTL) & MUSB_DEVCTL_VBUS) != MUSB_DEVCTL_VBUS)
        ;
}

void Usb_Host_Tx_Start(uint8_t Epnum)
{

    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {

        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_TXPKTRDY;

    } else {

        REG16(CONFIG_EP(Epnum) + MUSB_CSR0) |= MUSB_CSR0_H_SETUPPKT | MUSB_CSR0_TXPKTRDY;
    }
}

void Usb_Host_Tx_Flush_Fifo(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));
    uint8_t  retries = 5;
    uint16_t csr     = 0;

    if (Epnum) {
        csr = REG16(USB_BASE + MUSB_TXCSR);
        while (csr & MUSB_TXCSR_FIFONOTEMPTY) {
            csr |= MUSB_TXCSR_FLUSHFIFO | MUSB_TXCSR_TXPKTRDY;
            REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) = csr;
        }
    } else {

        csr = REG16(CONFIG_EP(EP0) + MUSB_CSR0);
        do {
            if (!(csr & (MUSB_CSR0_TXPKTRDY | MUSB_CSR0_RXPKTRDY)))
                break;
            REG16(CONFIG_EP(EP0) + MUSB_CSR0) = MUSB_CSR0_FLUSHFIFO; /* code */
        } while (--retries);
    }
}

uint16_t Usb_Host_Get_Frame_Number()
{
    return REG16(USB_BASE + MUSB_FRAME);
}

void Usb_Host_Resume(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {
        REG8(USB_BASE + MUSB_POWER) |= MUSB_POWER_RESUME;
    }

    else {
        REG8(USB_BASE + MUSB_POWER) &= ~MUSB_POWER_RESUME;
    }
}

void Usb_Host_Reset(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {
        REG8(USB_BASE + MUSB_POWER) |= MUSB_POWER_RESET;
    } else {
        REG8(USB_BASE + MUSB_POWER) &= ~MUSB_POWER_RESET;
    }
}

void Usb_Host_Suspend()
{
    REG8(USB_BASE + MUSB_POWER) |= MUSB_POWER_SUSPEND;
}

void Usb_Start_Session(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {
        REG8(USB_BASE + MUSB_DEVCTL) |= MUSB_DEVCTL_SESSION;
    } else {
        REG8(USB_BASE + MUSB_DEVCTL) &= ~MUSB_DEVCTL_SESSION;
    }
}

void Usb_Soft_Connect(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {

        REG8(USB_BASE + MUSB_POWER) = MUSB_POWER_SOFTCONN;
    } else {
        REG8(USB_BASE + MUSB_POWER) &= ~MUSB_POWER_SOFTCONN;
    }
}

void Usb_ISO_Update(FunctionalState NewState)
{
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == ENABLE) {

        REG8(USB_BASE + MUSB_POWER) = MUSB_POWER_ISOUPDATE;
    } else {
        REG8(USB_BASE + MUSB_POWER) &= ~MUSB_POWER_ISOUPDATE;
    }
}

void Usb_RX_Interrupt_Enable(uint8_t Epnum, FunctionalState NewState)

{
    assert_param(IS_FUNCTIONAL_STATE(NewState));
    assert_param(IS_USB_EPNUM(Epnum));

    if (NewState == ENABLE) {
        REG16(USB_BASE + MUSB_INTRRXE) |= (1 << Epnum);
    } else {
        REG16(USB_BASE + MUSB_INTRRXE) &= ~(1 << Epnum);
    }
}

void Usb_TX_Interrupt(uint8_t Epnum, FunctionalState NewState)

{
    assert_param(IS_FUNCTIONAL_STATE(NewState));
    assert_param(IS_USB_EPNUM(Epnum));

    if (NewState == ENABLE) {
        REG16(USB_BASE + MUSB_INTRTXE) |= (1 << Epnum);
    } else {
        REG16(USB_BASE + MUSB_INTRTXE) &= ~(1 << Epnum);
    }
}

void Usb_Host_Tx_Dma_Start(uint8_t Epnum)
{

    assert_param(IS_USB_EPNUM(Epnum));

    REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_DMAENAB | MUSB_TXCSR_DMAMODE;
}

void Usb_Host_Rx_Dma_Start(uint8_t Epnum)
{

    assert_param(IS_USB_EPNUM(Epnum));

    REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) &= ~MUSB_RXCSR_DMAENAB;
}

void Usb_Host_Req_IN_transaction(uint8_t Epnum)

{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) |= MUSB_RXCSR_H_REQPKT;
    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_H_REQPKT;
    }
}

void Usb_Host_Flush_Rxfifo(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));

    uint16_t csr = 0;

    csr |= MUSB_RXCSR_FLUSHFIFO | MUSB_RXCSR_RXPKTRDY;
    csr &= ~(MUSB_RXCSR_H_REQPKT | MUSB_RXCSR_H_AUTOREQ | MUSB_RXCSR_AUTOCLEAR);

    /* write 2x to allow double buffering */
    REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) = csr;
    REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) = csr;
}

void Usb_Stop()
{
    Usb_All_Interrupts(DISABLE);
    Usb_Start_Session(DISABLE);
}

void Usb_Host_Stop()
{
    Usb_Stop();
}

void Usb_Host_Tx_RX_Type(USB_HOST_TXRXTYPE_TypeDef *USB_HOST_RXTYPE, USB_TRANSFER_TYPE Type)
{
    assert_param(IS_USB_SPEED(USB_HOST_RXTYPE->SPEED));
    assert_param(IS_USB_SPEED(USB_HOST_RXTYPE->PROTOCOL));
    assert_param(IS_USB_EPNUM(USB_HOST_RXTYPE->EP_NUM));


    uint8_t type_reg = 0;

    switch (USB_HOST_RXTYPE->SPEED) {
    case USB_SPEED_LOW:
        type_reg |= 0xc0;
        break;
    case USB_SPEED_FULL:
        type_reg |= 0x80;
        break;
    default:
        type_reg |= 0x80;
    }

    type_reg |= (USB_HOST_RXTYPE->PROTOCOL) << 0x4 | USB_HOST_RXTYPE->EP_NUM;

    if (Type == TX) {
        REG16(CONFIG_EP(USB_HOST_RXTYPE->EP_NUM) + MUSB_TXCSR) |= MUSB_TXCSR_MODE;
        REG8(CONFIG_EP(USB_HOST_RXTYPE->EP_NUM) + MUSB_TXTYPE) = type_reg;
    }

    else {
        REG16(CONFIG_EP(USB_HOST_RXTYPE->EP_NUM) + MUSB_TXCSR) &= ~MUSB_TXCSR_MODE;
        REG8(CONFIG_EP(USB_HOST_RXTYPE->EP_NUM) + MUSB_RXTYPE) = type_reg;
    }
}

uint16_t Usb_Receive_Count(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum)
        return REG16(CONFIG_EP(Epnum) + MUSB_RXCOUNT);
    else
        return REG8(CONFIG_EP(Epnum) + MUSB_COUNT0);
}

void Usb_Host_Transmit_Setup(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) = MUSB_TXCSR_H_SETUPPKT | MUSB_TXCSR_TXPKTRDY;
    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) = MUSB_CSR0_H_SETUPPKT | MUSB_CSR0_TXPKTRDY;
    }
}

void Usb_Host_Out_Transaction(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_TXPKTRDY;
    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) &= ~MUSB_CSR0_H_SETUPPKT;
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_TXPKTRDY;
    }
}

void Usb_Set_Address(uint8_t Address)
{
    assert_param(IS_USB_Address(Address));

    REG8(USB_BASE + MUSB_FADDR) = Address;
}

void Usb_Host_Receive_data(uint8_t Epnum, uint8_t Buffer[])
{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {

        if (REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) & MUSB_RXCSR_RXPKTRDY)

        {

            Usb_Read_Fifo(Epnum, Buffer, Usb_Receive_Count(Epnum));

            REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) |= MUSB_RXCSR_FLUSHFIFO;
            REG16(CONFIG_EP(Epnum) + MUSB_RXCSR) &= ~MUSB_RXCSR_RXPKTRDY;
        }
    } else {

        if (REG16(CONFIG_EP(EP0) + MUSB_CSR0) & MUSB_CSR0_RXPKTRDY)

        {

            Usb_Read_Fifo(Epnum, Buffer, Usb_Receive_Count(Epnum));
            REG16(CONFIG_EP(EP0) + MUSB_CSR0) &= ~MUSB_CSR0_RXPKTRDY;
        }
    }
}

void Usb_Set_NAK_Interval(uint8_t Epnum, uint8_t NAK_Interval, FunctionalState NewState)
{
    assert_param(IS_USB_EPNUM(Epnum));
    assert_param(IS_FUNCTIONAL_STATE(NewState));
    assert_param(IS_USB_NAK(NAK_Interval));

    if (NewState == ENABLE) {
        if (Epnum) {

            REG16(CONFIG_EP(Epnum) + MUSB_TXINTERVAL) = NAK_Interval;

        } else {
            REG8(USB_BASE + MUSB_NAKLIMIT0) = NAK_Interval;
        }
    } else {
        REG16(CONFIG_EP(Epnum) + MUSB_TXINTERVAL) = 0;
    }
}

void Usb_Host_Toggle_Data(uint8_t Epnum)

{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_H_WR_DATATOGGLE | MUSB_TXCSR_H_DATATOGGLE;

    } else {

        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_H_WR_DATATOGGLE | MUSB_CSR0_H_DATATOGGLE;
    }
}

void Usb_Device_Transmiit(uint8_t Epnum)
{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_TXPKTRDY;

    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_TXPKTRDY;
    }
}

void Usb_Device_Clear_Setup()
{
    REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_P_SVDSETUPEND;
}

void Usb_Device_Clear_RXPktRdy()
{
    REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_P_SVDRXPKTRDY;
}

void Usb_Device_Flush_fifo(uint8_t Epnum)
{

    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_FLUSHFIFO;

    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_FLUSHFIFO;
    }
}

void Usb_Device_Tx_RX_Type(uint8_t Epnum, USB_TRANSFER_TYPE type)
{
    assert_param(IS_USB_EPNUM(Epnum));
    assert_param(IS_USB_TRANSFER_TYPE(type));

    if (Epnum) {
        REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) &= ~(MUSB_TXCSR_P_MODE);
        if (type == TX) {

            REG16(CONFIG_EP(Epnum) + MUSB_TXCSR) |= MUSB_TXCSR_P_MODE;
        } else {
        }
    }
}

void Usb_Device_Data_End()
{
    REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_P_DATAEND;
}

void Usb_Device_Send_Stall(uint8_t Epnum)

{
    assert_param(IS_USB_EPNUM(Epnum));

    if (Epnum) {
        REG16(CONFIG_EP(EP0) + MUSB_TXCSR) |= MUSB_TXCSR_P_SENDSTALL;

    } else {
        REG16(CONFIG_EP(EP0) + MUSB_CSR0) |= MUSB_CSR0_P_SENDSTALL;
    }
}

void Usb_Dma_Config(Usb_Dma_Channel_TypeDef *channel)
{

    uint16_t csr = 0;
    if (channel->MODE) {
        csr |= 1 << USB_DMA_MODE1_SHIFT;
    }
    csr |= USB_DMA_BURSTMODE_INCR16 << USB_DMA_BURSTMODE_SHIFT;

    csr |= (channel->EPNUM << USB_DMA_ENDPOINT_SHIFT) | (1 << USB_DMA_IRQENABLE_SHIFT) | (channel->TRANSMIT ? (1 << USB_DMA_TRANSMIT_SHIFT) : 0) |
           (1 << USB_DMA_ENABLE_SHIFT);

    REG32(USB_BASE + USB_DMA_CHANNEL_OFFSET(channel->IDX, USB_DMA_ADDRESS)) |= channel->START_ADDR;
    REG32(USB_BASE + USB_DMA_CHANNEL_OFFSET(channel->IDX, USB_DMA_COUNT))   = channel->LENGTH;
    REG16(USB_BASE + USB_DMA_CHANNEL_OFFSET(channel->IDX, USB_DMA_CONTROL)) = csr;
//    REG16(USB_BASE + USB_DMA_CHANNEL_OFFSET(channel->IDX, USB_DMA_INTR)) = 0x1;
}
