/*
 * Copyright (c) 2009-2019 Arm Limited. All rights reserved.
 * -- Adaptable modifications made for i-CORE Processors. --
 * Copyright (c) 2019 i-CORE Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <stdint.h>

#ifdef __cplusplus
 extern "C" {
#endif

#include "nmsis_version.h"

/**
 * \ingroup NMSIS_Core_VersionControl
 * @{
 */

#include "nmsis_compiler.h"     /* NMSIS compiler specific defines */

/* === Include i-CORE Core Related Headers === */
/* Include core base feature header file */
#include "core_feature_base.h"

/* Include core fpu feature header file */
#include "core_feature_fpu.h"
/* Include core dsp feature header file */
#include "core_feature_dsp.h"
/* Include core vector feature header file */
#include "core_feature_vector.h"
/* Include core bitmanip feature header file */
#include "core_feature_bitmanip.h"
/* Include core pmp feature header file */
#include "core_feature_pmp.h"
/* Include core spmp feature header file */
 #include "core_feature_spmp.h"
/* Include core cache feature header file */
#include "core_feature_cache.h"
/* Include core cidu feature header file */
 #include "core_feature_cidu.h"

/* Include compatiable functions header file */
#include "core_compatiable.h"

#ifndef __NMSIS_GENERIC
/* Include core eclic feature header file */
#include "core_feature_eclic.h"
/* Include core systimer feature header file */
#include "core_feature_timer.h"
#endif

#ifdef __cplusplus
}
#endif
