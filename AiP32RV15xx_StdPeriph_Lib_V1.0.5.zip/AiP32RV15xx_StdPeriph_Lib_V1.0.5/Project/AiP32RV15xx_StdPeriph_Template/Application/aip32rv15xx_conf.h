/**
 * @file AiP32RV15A8_config.h
 * @brief
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-01-07
 * @copyright Copyright (c) 2022 Timesintelli, Inc
 */

#ifndef __AiP32RV15A8_CONFIG_H
#define __AiP32RV15A8_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif


#define USART_MODULE_ENABLED
#define GPIO_MODULE_ENABLED
#define RCC_MODULE_ENABLED
#define CRC_MODULE_ENABLED
#define WWDG_MODULE_ENABLED
#define FLASH_MODULE_ENABLED
#define DMA_MODULE_ENABLED
#define RTC_MODULE_ENABLED
#define SPI_MODULE_ENABLED
#define ADC_MODULE_ENABLED
#define CAN_MODULE_ENABLED
#define TIM_MODULE_ENABLED
#define USB_MODULE_ENABLED
#define EXTI_MODULE_ENABLED
#define I2C_MODULE_ENABLED

#ifdef __cplusplus
}
#endif

#endif /* __AiP32RV15A8_CONFIG_H */
