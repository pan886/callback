/**
 * @file main.c
 * @brief  SPI poll test
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

#include <stdint.h>

#define SPIy SPI1
#define SPIy_CLK RCC_APB2Periph_SPI1
#define SPIy_GPIO GPIOA
#define SPIy_GPIO_CLK RCC_APB2Periph_GPIOA
#define SPIy_PIN_CSN GPIO_Pin_4
#define SPIy_PIN_SCK GPIO_Pin_5
#define SPIy_PIN_MISO GPIO_Pin_6
#define SPIy_PIN_MOSI GPIO_Pin_7

void GPIO_Configuration(void) {
  GPIO_InitTypeDef GPIO_InitStructure;

  /** Remap SPI1 use PA4 PA5 PA6 PA7 */
  GPIO_PinRemapConfig(GPIO_Remap_SPI1, DISABLE);
  /** Remap SPI2 use PB12 PB13 PB14 PB15 */
  GPIO_PinRemapConfig(GPIO_Remap_SPI2, ENABLE);
  /* Configure SPIx as AF mode */
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin =
      SPIy_PIN_CSN | SPIy_PIN_SCK | SPIy_PIN_MOSI | SPIy_PIN_MISO;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_Init(SPIy_GPIO, &GPIO_InitStructure);
}

void main(void) {
  SPI_InitTypeDef SPI_InitStructure;
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  debug("running\n");
  GPIO_Configuration();
  /**1st phase: SPIy as master,SPIz as slave. */
  SPI_DeInit(SPIy);

  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_32;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  /** Configure SPIy*/
  SPI_Init(SPIy, &SPI_InitStructure);

  /** Enable SPIy CSN */
  SPI_SSOutputCmd(SPIy, ENABLE);
  /** Enable SPIy */
  SPI_Cmd(SPIy, ENABLE);

  while (1) {
    SPI_SendData(SPIy, 0xaa);
  }
}
