/**
 * @file main.c
 * @brief  In this demo. It shows how to use CRC to calculate the CRC value.If
 * the result is success, We can observe "crc success!" through serial port.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

uint32_t data[] = {0x12345678, 0x9};
uint32_t d1 = 0;
int main(void) {

  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, ENABLE);

  CRC_SeedConfig(0x0);
  CRC_InputControl(CRC_Not_Reverse, CRC_32);

  debug("CRC running!\n");

  if (CRC_CalcCRC(0x12345678) == 0x188E5750) {
    debug("CRC32 cal success!\n");
  }
  CRC_ClearValue();
  if (CRC_CalcBlockCRC(data, 2) == 0xd438ab2e)

  {
    debug("CRC calblock success!\n");
  }

  CRC_SeedConfig(0x0);
  CRC_InputControl(CRC_Not_Reverse, CRC_16);
  if (CRC_CalcCRC(0x12345678) == 0xb42C) {
    debug("CRC16 cal success!\n");
  }

  while (1) {
  }
}
