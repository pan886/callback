/**
 * @file main.c
 * @brief usb device example
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"
#include "usb_desc.h"
#define CURSOR_STEP 5

void delay(uint16_t xms) {
  volatile uint16_t i, j = 0;
  for (i = 0; i < 0xff; i++)
    for (j = 0; j <= xms; j++)
      ;
}

uint8_t buf[8] = {0};
uint8_t ep1_buf[4] = {0, 0, 0, 0};
void mouse_send() {
  ep1_buf[1] += CURSOR_STEP;
  Usb_Write_Fifo(EP1, ep1_buf, 4);
  Usb_Device_Transmiit(EP1);
}

GPIO_InitTypeDef GPIOA_struct;
USB_DeviceMess *pInformation;
GPIO_InitTypeDef GPIOE_struct;
void Cfg_IO(void) {
  GPIOA_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIOA_struct.GPIO_Pin = GPIO_Pin_0;
  GPIO_Init(GPIOA, &GPIOA_struct);
  AFIO->GPIO[0].IC &= ~(0x3 << 27);
  GPIOA_struct.GPIO_Mode = GPIO_Mode_AIN;
  GPIOA_struct.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_11;
  GPIO_Init(GPIOA, &GPIOA_struct);

  GPIOE_struct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIOE_struct.GPIO_Pin = GPIO_Pin_2;
  GPIO_Init(GPIOE, &GPIOE_struct);
  GPIO_SetBits(GPIOE, GPIO_Pin_2);
}

void USBF_MC_IRQHandler(void) {

  if (REG16(CONFIG_EP(EP0) + MUSB_CSR0) & MUSB_CSR0_RXPKTRDY) {

    Usb_Device_Clear_Setup();
    pInformation = (USB_DeviceMess *)Usb_Read_Fifo(EP0, buf, 8);
    uint32_t Request_No = pInformation->bRequest;
    /*  clear the RxPktRdy bit. indicating that the command has read from the
     * FIFO*/
    Usb_Device_Clear_RXPktRdy();
    Usb_Device_Flush_fifo(EP0);
    if ((Request_No == SET_ADDRESS)) {
      delay(0xf);
      Usb_Set_Address(pInformation->USBwValue0);
      REG16(CONFIG_EP(EP0) + MUSB_CSR0) = MUSB_CSR0_P_DATAEND;
    }
    if ((Request_No == GET_DESCRIPTOR)) {
      if ((pInformation->USBwValue1 == DEVICE_DESCRIPTOR)) {

        Usb_Write_Fifo(EP0, DeviceDescriptor, SIZ_DEVICE_DESC);
      }

      if ((pInformation->USBwValue1 == CONFIG_DESCRIPTOR)) {
        if (pInformation->USBwLength0 == 0xff) {

          Usb_Write_Fifo(EP0, ConfigDescriptor, SIZ_CONFIG_DESC);
        }
        /*config*/
        if ((pInformation->USBwLength0 < 0xff)) {

          Usb_Write_Fifo(EP0, ConfigDescriptor, pInformation->USBwLength0);
        }
      }

      if ((pInformation->USBwValue1 == STRING_DESCRIPTOR)) {
        /*serial number*/
        if ((pInformation->USBwValue0 == STRING3)) {

          Usb_Write_Fifo(EP0, StringSerial, SIZ_STRING_SERIAL);
        }
        /* lang ID*/
        if ((pInformation->USBwIndex == STRING0)) {

          Usb_Write_Fifo(EP0, StringLangID, SIZ_STRING_LANGID);
        }
        /*string iproduct*/
        if ((pInformation->USBwValue0 == STRING2)) {

          Usb_Write_Fifo(EP0, StringProduct, SIZ_STRING_PRODUCT);
        }
      }

      /*device qualifier*/
      if (pInformation->USBwValue1 == QUALIFIER_DESCRIPTOR) {
        Usb_Device_Send_Stall(EP0);
      }
      Usb_Device_Data_End();
      Usb_Device_Transmiit(EP0);
    }

    /*set idle*/
    if ((Request_No == GET_INTERFACE)) {
      Usb_Device_Data_End();
      Usb_Device_Send_Stall(EP0);
    }

    if ((pInformation->USBwValue1 == REPORT_DESCRIPTOR)) {

      Usb_Write_Fifo(EP0, ReportDescriptor, SIZ_REPORT_DESC);

      Usb_Device_Transmiit(EP0);
      /*config ep1*/
      Usb_Device_Tx_RX_Type(EP1, TX);
    }
  }

  {

    if (REG16(CONFIG_EP(EP1) + MUSB_TXCSR) & MUSB_TXCSR_P_UNDERRUN) {
      REG16(CONFIG_EP(EP1) + MUSB_TXCSR) &= ~MUSB_TXCSR_P_UNDERRUN;
      Usb_Device_Flush_fifo(EP1);
      if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == Bit_RESET) {
        mouse_send();
      } else {
      }
    }
  }
}

void Set_System(void) {
  RCC->USBPHY_CTRL.CLK_MODE_BIT = 0x1;
  RCC->USBPHY_CTRL.PLL_EN_BIT = 0x1;
  RCC->USBPHY_CTRL.IDDIG_BIT = 0x1;
  RCC->USBPHY_CTRL.REFCLK_SEL_BIT = 0x1;
  /*USB AHB clk enable*/
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_USB, ENABLE);
  RCC_AHBPeriphResetCmd(RCC_AHBPeriph_USB, ENABLE);
  RCC_AHBPeriphResetCmd(RCC_AHBPeriph_USB, DISABLE);

  RCC_OTGFSCLKConfig(0xB); /*usb PHY ref clk(12M) div(TBD) */
  RCC->USBPHY_CTRL.value = 0x0;
  RCC->USBPHY_CTRL.IDDIG_BIT = 0x1;
  RCC->USBPHY_CTRL.CLK_MODE_BIT = 0x1;
  RCC->USBPHY_CTRL.AVALID_BIT = 0x1;

  ECLIC_Register_IRQ(USB_MC_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
                     ECLIC_LEVEL_TRIGGER, 3, 0, (void *)USBF_MC_IRQHandler);

  __enable_irq();
}

void main(void) {
  uint8_t val = 0;
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);
  Set_System();
  Cfg_IO();
  pProperty = &Device_Property;
  pProperty->Init();

  while (1) {

    debug("main progress!\n");
  }
}

void Usb_init() {

  Usb_Wait_Vbusvalid();
  Usb_All_Interrupts(DISABLE);
  Usb_ISO_Update(ENABLE);
  Usb_All_Interrupts(ENABLE);
  Usb_Start_Session(ENABLE);
  Usb_Soft_Connect(ENABLE);
}
