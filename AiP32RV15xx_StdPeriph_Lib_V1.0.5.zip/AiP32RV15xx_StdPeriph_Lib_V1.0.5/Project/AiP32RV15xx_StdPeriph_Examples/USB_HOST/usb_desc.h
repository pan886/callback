
/**
 * @file usb_desc.h
 * @brief Defined USB device descriptor array.
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-11-21
 * @copyright Copyright (c) 2022 Icore, Inc
 */
#include "AiP32RV15xx.h"

#define printf tfp_printf
#define sprintf tfp_sprintf

#define USB_DEVICE_DESCRIPTOR_TYPE 0x01
#define USB_CONFIGURATION_DESCRIPTOR_TYPE 0x02
#define USB_STRING_DESCRIPTOR_TYPE 0x03
#define USB_INTERFACE_DESCRIPTOR_TYPE 0x04
#define USB_ENDPOINT_DESCRIPTOR_TYPE 0x05

#define HID_DESCRIPTOR_TYPE 0x21
#define JOYSTICK_SIZ_HID_DESC 0x09
#define JOYSTICK_OFF_HID_DESC 0x12

#define SIZ_DEVICE_DESC 18
#define SIZ_CONFIG_DESC 34
#define SIZ_REPORT_DESC 46
#define SIZ_STRING_LANGID 4
#define SIZ_STRING_VENDOR 38
#define SIZ_STRING_PRODUCT 33
#define SIZ_STRING_SERIAL 21

#define STANDARD_ENDPOINT_DESC_SIZE 0x09
#define SETUP_SIZE 0x8

extern uint8_t HOST_Discriptor_Device_SetUp[SETUP_SIZE];

extern uint8_t HOST_Discriptor_Iserial_Number[SETUP_SIZE];

extern uint8_t Host_Set_Idle[SETUP_SIZE];

extern uint8_t Host_Discriptor_report[SETUP_SIZE];

extern uint8_t Host_Set_Configuration[SETUP_SIZE];

extern uint8_t HOST_Set_Address_Setup[SETUP_SIZE];

extern uint8_t Host_Discriptor_LangID[SETUP_SIZE];

extern uint8_t Host_Discriptor_Iproduct[SETUP_SIZE];

extern uint8_t Host_Discriptor_configuration[SETUP_SIZE];

extern const uint8_t ConfigDescriptor[SIZ_CONFIG_DESC];
extern uint8_t StringSerial[SIZ_STRING_SERIAL];
extern const uint8_t StringLangID[SIZ_STRING_LANGID];
extern const uint8_t StringProduct[SIZ_STRING_PRODUCT];
extern const uint8_t ReportDescriptor[SIZ_REPORT_DESC];
extern const uint8_t DeviceDescriptor[SIZ_DEVICE_DESC];

typedef union {
  uint16_t w;
  struct BW {
    uint8_t bb0;
    uint8_t bb1;
  } bw;
} uint16_t_uint8_t;

typedef struct _DEVICE_INFO {
  uint8_t bmRequestType;     /* bmRequestType */
  uint8_t bRequest;          /* bRequest */
  uint16_t_uint8_t wValues;  /* wValue */
  uint16_t_uint8_t wIndexs;  /* wIndex */
  uint16_t_uint8_t wLengths; /* wLength */

} USB_DeviceMess;

typedef struct _DEVICE_PROP {
  void (*Init)(void); /* Initialize the device */

  uint8_t MaxPacketSize;

} DEVICE_PROP;

#define USB_DEVICE_DESCRIPTOR_TYPE 0x01
#define USB_CONFIGURATION_DESCRIPTOR_TYPE 0x02
#define USB_STRING_DESCRIPTOR_TYPE 0x03
#define USB_INTERFACE_DESCRIPTOR_TYPE 0x04
#define USB_ENDPOINT_DESCRIPTOR_TYPE 0x05

#define HID_DESCRIPTOR_TYPE 0x21
#define JOYSTICK_SIZ_HID_DESC 0x09
#define JOYSTICK_OFF_HID_DESC 0x12

#define SIZ_DEVICE_DESC 18
#define SIZ_CONFIG_DESC 34
#define SIZ_REPORT_DESC 46
#define SIZ_STRING_LANGID 4
#define SIZ_STRING_VENDOR 38
#define SIZ_STRING_PRODUCT 33
#define SIZ_STRING_SERIAL 21

#define STANDARD_ENDPOINT_DESC_SIZE 0x09
extern const uint8_t ConfigDescriptor[SIZ_CONFIG_DESC];
extern uint8_t StringSerial[SIZ_STRING_SERIAL];
extern const uint8_t StringLangID[SIZ_STRING_LANGID];
extern const uint8_t StringProduct[SIZ_STRING_PRODUCT];
extern const uint8_t ReportDescriptor[SIZ_REPORT_DESC];
extern const uint8_t DeviceDescriptor[SIZ_DEVICE_DESC];

// extern USB_DeviceMess *pInformation;
void Usb_init(void);

typedef struct OneDescriptor {
  uint8_t *Descriptor;
  uint16_t Descriptor_Size;
} USB_OneDescriptor, *PONE_DESCRIPTOR;

typedef enum _STANDARD_REQUESTS {
  GET_STATUS = 0,
  CLR_FEATURE,
  RESERVED1,
  SET_FEATURE,
  RESERVED2,
  SET_ADDRESS,
  GET_DESCRIPTOR,
  SET_DESCRIPTOR,
  GET_CONFIGURATION,
  SET_CONFIGURATION,
  GET_INTERFACE,
  SET_INTERFACE,
  TOTAL_SREQUEST, /* Total number of Standard request */
  SYNCH_FRAME = 12
} STANDARD_REQUESTS;

enum STRING_TYPE {
  STRING0 = 0x0,
  STRING2 = 0x2,
  STRING3 = 0x3,
};

/* Definition of "USBwValue" */
typedef enum _DESCRIPTOR_TYPE {
  DEVICE_DESCRIPTOR = 1,
  CONFIG_DESCRIPTOR,
  STRING_DESCRIPTOR,
  INTERFACE_DESCRIPTOR,
  ENDPOINT_DESCRIPTOR,
  QUALIFIER_DESCRIPTOR,
  REPORT_DESCRIPTOR = 0x22,

} DESCRIPTOR_TYPE;

#define USBwValue wValues.w
#define USBwValue0 wValues.bw.bb0
#define USBwValue1 wValues.bw.bb1
#define USBwIndex wIndexs.w
#define USBwIndex0 wIndexs.bw.bb0
#define USBwIndex1 wIndexs.bw.bb1
#define USBwLength wLengths.w
#define USBwLength0 wLengths.bw.bb0
#define USBwLength1 wLengths.bw.bb1
