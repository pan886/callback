/**
 * @file main.c
 * @brief usb host example
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"
#include "usb_desc.h"
#define USB_DMA_MODE 1
void USB_MC_IRQHandler(void);
uint8_t cnt = 0;
uint8_t flg = 0;

void delay() {
  volatile uint16_t i, j = 0;
  for (i = 0; i < 0x1ff; i++)
    for (j = 0; j < 0xff; j++)
      ;
}

GPIO_InitTypeDef GPIOA_struct;
USB_HOST_TXRXTYPE_TypeDef Usb_Host_Rxtype;
USB_HOST_TXRXTYPE_TypeDef Usb_Host_Txtype;
Usb_Dma_Channel_TypeDef Usb_Dma_Channel_Type;
uint8_t rxbuf[4] = {0};
void USBF_MC_IRQHandler(void);
void Cfg_IO(void) {
  GPIOA_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIOA_struct.GPIO_Pin = GPIO_Pin_0;
  GPIO_Init(GPIOA, &GPIOA_struct);
  AFIO->GPIO[0].IC &= ~(0x3 << 27);
  GPIOA_struct.GPIO_Mode = GPIO_Mode_AIN;
  GPIOA_struct.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_11;
  GPIO_Init(GPIOA, &GPIOA_struct);
}

void Set_System(void) {
  RCC->USBPHY_CTRL.CLK_MODE_BIT = 0x1;
  RCC->USBPHY_CTRL.PLL_EN_BIT = 0x1;
  RCC->USBPHY_CTRL.IDDIG_BIT = 0; /*host*/
  RCC->USBPHY_CTRL.REFCLK_SEL_BIT = 0x0;
  /*USB AHB clk enable*/
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_USB, ENABLE);
  RCC_AHBPeriphResetCmd(RCC_AHBPeriph_USB, ENABLE);
  RCC_AHBPeriphResetCmd(RCC_AHBPeriph_USB, DISABLE);

  RCC_AHBPeriphResetCmd(RCC_AHBPeriph_DMA, ENABLE);

  RCC_OTGFSCLKConfig(0xB); /*usb PHY ref clk(12M) div(TBD)*/

  RCC->USBPHY_CTRL.IDDIG_BIT = 0;
  RCC->USBPHY_CTRL.CLK_MODE_BIT = 0x1;
  RCC->USBPHY_CTRL.AVALID_BIT = 0x1;
  RCC->USBPHY_CTRL.VBUSVAILD_BIT = 0x1;

  ECLIC_Register_IRQ(USB_MC_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
                     ECLIC_LEVEL_TRIGGER, 3, 0, (void *)USBF_MC_IRQHandler);

  __enable_irq();
}

void Usb_Dma_receive() {
  uint8_t i = 0;
  if (REG16(CONFIG_EP(EP1) + MUSB_RXCSR) & MUSB_RXCSR_RXPKTRDY)

  {

    Usb_Host_Rx_Dma_Start(EP1);
    if (REG16(USB_BASE + MUSB_INTRRX) == 0x2) {
      Usb_Dma_Channel_Type.EPNUM = EP1;
      Usb_Dma_Channel_Type.IDX = 0x0;
      Usb_Dma_Channel_Type.TRANSMIT = RX;
      Usb_Dma_Channel_Type.MODE = 0;
      Usb_Dma_Channel_Type.START_ADDR |= ((uint32_t)((rxbuf)));
      Usb_Dma_Channel_Type.LENGTH = Usb_Receive_Count(EP1);
      Usb_Dma_Config(&Usb_Dma_Channel_Type);
    }

    if (REG16(USB_BASE + USB_DMA_INTR) == 0x1) {

      for (i = 0; i < 4; i++)
        debug("rxbuf = %x\n", rxbuf[i]);
      debug("ctnl = %x\n", REG16(USB_BASE + 0x204));
      debug("count = %x\n", REG16(USB_BASE + 0x20C));
      debug("rxbuf = %x\n", (uint32_t)((rxbuf)));
      debug("addrr = %x\n", REG32(USB_BASE + 0x208));
      REG16(CONFIG_EP(EP1) + MUSB_RXCSR) &= ~MUSB_RXCSR_RXPKTRDY;
    }
  }
}

void Usb_receive() {
  uint8_t i = 0;
  if (REG16(CONFIG_EP(EP1) + MUSB_RXCSR) & MUSB_RXCSR_RXPKTRDY) {
    Usb_Read_Fifo(EP1, rxbuf, Usb_Receive_Count(EP1));
    for (i = 0; i < 4; i++)
      debug("rxbuf = %x\n", rxbuf[i]);
    REG16(CONFIG_EP(EP1) + MUSB_RXCSR) |= MUSB_RXCSR_FLUSHFIFO;
    REG16(CONFIG_EP(EP1) + MUSB_RXCSR) &= ~MUSB_RXCSR_RXPKTRDY;
  }
}

uint8_t EPFIFO[100] = {0};

void main(void) {

  uint8_t val = 0;
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  Set_System();
  Cfg_IO();
  Usb_init();
  Usb_Set_Host_Mode();

  Usb_Host_Rxtype.SPEED = USB_SPEED_FULL;
  Usb_Host_Rxtype.PROTOCOL = INTERRUPT;
  Usb_Host_Rxtype.EP_NUM = EP1;

  Usb_Host_Txtype.SPEED = USB_SPEED_FULL;
  Usb_Host_Txtype.PROTOCOL = INTERRUPT;
  Usb_Host_Txtype.EP_NUM = EP7;

  Usb_Host_Rx_Dma_Start(EP1);

  Usb_Host_Wait();
  Usb_Start_Session(ENABLE);

  REG16(CONFIG_EP(EP1) + MUSB_RXCSR) &=
      ~(MUSB_RXCSR_P_ISO | MUSB_RXCSR_DMAENAB);
  REG16(CONFIG_EP(EP1) + MUSB_RXCSR) |=
      MUSB_RXCSR_AUTOCLEAR | MUSB_RXCSR_H_AUTOREQ | MUSB_RXCSR_DMAMODE;
  REG16(CONFIG_EP(EP1) + MUSB_RXMAXP) = 0xff;
  while (1) {
    debug("main progress!\n");
  }
}

void Usb_init() { Usb_All_Interrupts(ENABLE); }

void USBF_MC_IRQHandler(void) {
  int i = 0;
  uint8_t INTRUSB = 0;

  debug("enter int!!!!!!!!!!!!!!!\n");

  INTRUSB = REG8(USB_BASE + MUSB_INTRUSB);

  if (INTRUSB & MUSB_INTR_SESSREQ) {

    REG8(USB_BASE + MUSB_DEVCTL) = MUSB_DEVCTL_SESSION | MUSB_DEVCTL_HM;
    debug("Session Request signaling has been detected.\n");
  }

  if (INTRUSB & MUSB_INTR_CONNECT) {
    Usb_Host_Reset(ENABLE);
    delay();
    Usb_Host_Reset(DISABLE);

    debug("enter connect interrupt!\n");

    REG8(USB_BASE + MUSB_DEVCTL) =
        MUSB_DEVCTL_SESSION | MUSB_DEVCTL_HM | MUSB_INTR_CONNECT;
  }

  if (INTRUSB & MUSB_INTR_SOF) {
    debug("enter sof interrupt!\n");

    {
      if (cnt < 21) {

        if ((REG16(CONFIG_EP(EP0) + MUSB_CSR0) & MUSB_CSR0_TXPKTRDY) == 0) {

          cnt++;

          if ((cnt % 21 == 0x1)) {

            Usb_Write_Fifo(EP0, HOST_Discriptor_Device_SetUp, SETUP_SIZE);
          }

          if ((cnt % 21 == 0x2)) {
            HOST_Set_Address_Setup[2] = 0x20;
            Usb_Write_Fifo(EP0, HOST_Set_Address_Setup, SETUP_SIZE);
          }

          if ((cnt % 21 == 0x3)) {
            Usb_Set_Address(0x20);
            HOST_Discriptor_Device_SetUp[6] = 0x12;
            Usb_Write_Fifo(EP0, HOST_Discriptor_Device_SetUp, SETUP_SIZE);
          }

          if ((cnt % 21 == 0x5) || (cnt % 21 == 0xe)) {
            Usb_Write_Fifo(EP0, HOST_Discriptor_Iserial_Number, SETUP_SIZE);
          }

          if ((cnt % 21 == 0x6) || (cnt % 21 == 0xf)) {

            Usb_Write_Fifo(EP0, Host_Discriptor_LangID, SETUP_SIZE);
          }

          if ((cnt % 21 == 0x7) || (cnt % 21 == 0x10)) {

            Usb_Write_Fifo(EP0, Host_Discriptor_Iproduct, SETUP_SIZE);
          }
          if ((cnt % 21 == 0x8) || (cnt % 21 == 0x11)) {
            Usb_Write_Fifo(EP0, Host_Discriptor_configuration, SETUP_SIZE);
          }
          if ((cnt % 21 == 0x4) || (cnt % 21 == 0x9) || (cnt % 21 == 0x12)) {

            Usb_Write_Fifo(EP0, Host_Discriptor_configuration, SETUP_SIZE);
          }

          if ((cnt % 21 == 0xA)) {
            Usb_Set_Address(0x0);
            HOST_Discriptor_Device_SetUp[6] = 0x40;
            Usb_Write_Fifo(EP0, HOST_Discriptor_Device_SetUp, SETUP_SIZE);
          }

          if (cnt % 21 == 0xB) {
            HOST_Set_Address_Setup[2] = 0x21;
            Usb_Write_Fifo(EP0, HOST_Set_Address_Setup, SETUP_SIZE);
          }

          if (cnt % 21 == 0xC) {
            Usb_Set_Address(0x21);
            HOST_Discriptor_Device_SetUp[6] = 0x12;
            Usb_Write_Fifo(EP0, HOST_Discriptor_Device_SetUp, SETUP_SIZE);
          }

          if (cnt % 21 == 0xd) {
            Host_Discriptor_configuration[6] = 0x22;
            Usb_Write_Fifo(EP0, Host_Discriptor_configuration, SETUP_SIZE);
          }
          if (cnt % 21 == 0x13) {
            Usb_Write_Fifo(EP0, Host_Set_Configuration, SETUP_SIZE);
          }
          if (cnt % 21 == 0x14) {
            Usb_Write_Fifo(EP0, Host_Set_Idle, SETUP_SIZE);
          }
          if (cnt % 21 == 0) {
            Usb_Write_Fifo(EP0, Host_Discriptor_report, SETUP_SIZE);
          }
          Usb_Host_Transmit_Setup(EP0);
        }

        while ((REG16(CONFIG_EP(EP0) + MUSB_CSR0) & MUSB_CSR0_TXPKTRDY))
          ;

        {
          Usb_Host_Req_IN_transaction(EP0);

          delay();
        }

        Usb_Host_Receive_data(EP0, EPFIFO);

        if (cnt % 21 == 0) {
          Usb_Host_Req_IN_transaction(EP0);
          Usb_Host_Receive_data(EP0, EPFIFO);
          flg = 1;
        }

        {
          if ((cnt % 21 != 0x2) && (cnt % 21 != 0xb) && (cnt % 21 != 0x13) &&
              (cnt % 21 != 0x14)) {

            Usb_Host_Receive_data(EP0, EPFIFO);

            Usb_Host_Out_Transaction(EP0);
          }
        }

        {
          if ((cnt % 21 == 0x1) || (cnt % 21 == 0x9) || (cnt % 21 == 0xA)) {
            Usb_Host_Reset(ENABLE);
            delay();
            Usb_Host_Reset(DISABLE);
          }
        }
      }
      if (flg == 0x1) {
        Usb_Host_Tx_RX_Type(&Usb_Host_Rxtype, RX);

        Usb_Host_Req_IN_transaction(EP1);
        // Usb_Host_Receive_data(EP1, EPFIFO);

#if USB_DMA_MODE
        Usb_Dma_receive();

#else
        Usb_receive();
#endif
      }
    }
  }
}
