/**
 * @file main.c
 * @brief

 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

#include <stdio.h>
#include <stdlib.h>

GPIO_InitTypeDef GPIOB_struct;
void GPIO_test(void);
uint8_t state = 0;
void main(void) {
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  /*Push-pull output mode */
  GPIOB_struct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIOB_struct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIOB_struct.GPIO_Speed = GPIO_Speed_2MHz;
  /*initialization pin PE2 PE3 PE4 PE5 PE6*/
  GPIO_Init(GPIOB, &GPIOB_struct);

  for (uint32_t i = 0; i < 100; i++) {
    debug("hello world!!!\r\n");
  }

  while (1) {
    GPIO_test();
  }
}

void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint16_t PortVal) {
  GPIOx->DATA ^= PortVal;
}
void delay() {
  volatile uint16_t i, j;
  for (i = 0; i < 0xfff; i++)
    for (j = 0; j < 0xff; j++)
      ;
}
void GPIO_test() {

  GPIO_Toggle(GPIOB, GPIO_Pin_13);
  delay();
  GPIO_Toggle(GPIOB, GPIO_Pin_14);
  delay();
  GPIO_Toggle(GPIOB, GPIO_Pin_15);
  delay();
  GPIO_Toggle(GPIOB, GPIO_Pin_15);
  delay();
  GPIO_Toggle(GPIOB, GPIO_Pin_14);
  delay();
  GPIO_Toggle(GPIOB, GPIO_Pin_13);
  delay();
}
