/**
 * @file main.c
 * @brief  TIM PWM example:Using timer interrupt generated PWM to control LED
 * brightness. Connect GND to The negative of LED; Connect PE9(TIM1_CH1) to The
 * positive of LED;
 * @author MCD Application Team
 * @version 1.0
 * @date 2024-11-16
 * @copyright Copyright (c) 2024 Icore, Inc
 */

#include "AiP32RV15xx.h"
TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
TIM_OCInitTypeDef TIM_OCInitStructure;
USART_InitTypeDef USART_InitStructure;
GPIO_InitTypeDef GPIO_InitStructure;

void TIM1_Init() {
  /* Internal clock to provide the clock source for TIM1 */
  TIM_InternalClockConfig(TIM1);

  /* TIM1 REMAP */
  GPIO_PinRemapConfig(GPIO_FullRemap_TIM1, ENABLE);
  /* GPIO configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOE, &GPIO_InitStructure);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 2;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 899;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
  /* Enables TIM1 interrupt */
  TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

  /* Channel 3 Configuration in PWM mode */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM1, &TIM_OCInitStructure);

  /* Enable the preloaded register of TIM1 on CCR1 */
  TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);

  /* Enable the ARR Preload */
  TIM_ARRPreloadConfig(TIM1, ENABLE);

  /* TIM1 counter enable */
  TIM_Cmd(TIM1, ENABLE);

  /* TIM1 PWM Output Enable */
  TIM_CtrlPWMOutputs(TIM1, ENABLE);
}
void TIM2_Init() {
  /* Internal clock to provide the clock source for TIM2 */
  TIM_InternalClockConfig(TIM2);

  /* TIM2 REMAP */
  GPIO_PinRemapConfig(GPIO_FullRemap_TIM2, ENABLE);
  GPIO_PinRemapConfig(GPIO_FullRemap_USART3, ENABLE);

  /* GPIO configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 2;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 899;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  /* Enables TIM2 interrupt */
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

  /* Channel 3 Configuration in PWM mode */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC3Init(TIM2, &TIM_OCInitStructure);

  /* Enable the preloaded register of TIM2 on CCR1 */
  TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);

  /* Enable the ARR Preload */
  TIM_ARRPreloadConfig(TIM2, ENABLE);

  /* TIM2 counter enable */
  TIM_Cmd(TIM2, ENABLE);
}
void TIM3_Init() {
  /* Internal clock to provide the clock source for TIM3 */
  TIM_InternalClockConfig(TIM3);

  /* TIM3 REMAP */
  GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);
  /* GPIO configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 2;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 899;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  /* Enables TIM3 interrupt */
  TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

  /* Channel 3 Configuration in PWM mode */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM3, &TIM_OCInitStructure);

  /* Enable the preloaded register of TIM3 on CCR1 */
  TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* Enable the ARR Preload */
  TIM_ARRPreloadConfig(TIM3, ENABLE);

  /* TIM3 counter enable */
  TIM_Cmd(TIM3, ENABLE);
}
void TIM4_Init() {
  /* Internal clock to provide the clock source for TIM4 */
  TIM_InternalClockConfig(TIM4);

  /* TIM4 REMAP */
  GPIO_PinRemapConfig(GPIO_Remap_TIM4, ENABLE);
  GPIO_PinRemapConfig(GPIO_PartialRemap_USART3, DISABLE);

  /* GPIO configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 2;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 899;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  /* Enables TIM4 interrupt */
  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

  /* Channel 3 Configuration in PWM mode */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM4, &TIM_OCInitStructure);

  /* Enable the preloaded register of TIM4 on CCR1 */
  TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);

  /* Enable the ARR Preload */
  TIM_ARRPreloadConfig(TIM4, ENABLE);

  /* TIM4 counter enable */
  TIM_Cmd(TIM4, ENABLE);
}
void main(void) {
  uint16_t pwmvalue1, pwmvalue2, pwmvalue3, pwmvalue4;
  uint8_t dir = 1;
  pwmvalue1 = 100;
  pwmvalue2 = 300;
  pwmvalue3 = 500;
  pwmvalue4 = 700;
  pll_init();

  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  TIM1_Init();
  TIM2_Init();
  TIM3_Init();
  TIM4_Init();
  /* SET CCRX count */
  TIM_SetCompare1(TIM1, pwmvalue1);
  TIM_SetCompare3(TIM2, pwmvalue2);
  TIM_SetCompare1(TIM3, pwmvalue3);
  TIM_SetCompare1(TIM4, pwmvalue4);
  debug("TIM1 PWMOutput = %d\r\n", pwmvalue1);
  debug("TIM2 PWMOutput = %d\r\n", pwmvalue2);
  debug("TIM3 PWMOutput = %d\r\n", pwmvalue3);
  debug("TIM4 PWMOutput = %d\r\n", pwmvalue4);

  while (1) {
  }
}
