/**
 * @file main.c
 * @brief This demo shows how to use PMU module.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

GPIO_InitTypeDef GPIOE_struct1;
GPIO_InitTypeDef GPIOE_struct2;

void delay() {
  volatile uint16_t i, j;
  for (i = 0; i < 0xfff; i++)
    for (j = 0; j < 0x3ff; j++)
      ;
}

void main(void) {

  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  /*Push-pull output mode */
  GPIOE_struct1.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIOE_struct1.GPIO_Pin =
      GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
  GPIOE_struct1.GPIO_Speed = GPIO_Speed_2MHz;
  /*initialization pin PE2 PE3 PE4 PE5 PE6*/
  GPIO_Init(GPIOE, &GPIOE_struct1);

  delay();
  GPIO_SetBits(GPIOE, GPIO_Pin_2);

  delay();

  PMU_PA0(pull_up);

  enter_stop_mode();

  while (1) {
  }
}
