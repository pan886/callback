/**
 * @file main.c
 * @brief  spi dma example.
 This example provides a basic communication between SPI_MASTER and SPI_SLAVE
 using DMA.
 * The SPI_MASTER,acts as spi master,communicates with the SPI_SLAVE,acts as spi
 slave,in SPI FullDuplex mode.
 * The SPI transaction length  is 64 bytes
 * The SPI_MASTER transfers the data to be sent to txfifo from
 dmaSPI_MASTER_Buffer_Tx memory via DMA channel1,
 * and transfers the rxfifo data to  dmaSPI_MASTER_Buffer_Rx memory via  DMA
 channel2;
 * The SPI_SLAVE transfers the data to be sent to txfifo from
 dmaSPI_SLAVE_Buffer_Tx
 * memory via DMA channel3,transfers the rxfifo data to  dmaSPI_SLAVE_Buffer_Rx
 memory via  DMA channel4.
 *
 * The example will check whether the DMA transactions are done. If already
 completed,the example will
 * compare the 64 bytes data in dmaSPI_MASTER_Buffer_Tx memory with the data in
 dmaSPI_SLAVE_Buffer_Rx memory,
 * the 64 bytes data in dmaSPI_SLAVE_Buffer_Tx memory with the data in
 dmaSPI_MASTER_Buffer_Rx memory, and prints
 * the result by UART.

 * Connect SPIy CSN pin (PA.04) to SPIz CSN pin (PB.12).
 * Connect SPIy SCK pin (PA.05) to SPIz SCK pin (PB.13).
 * Connect SPIy MISO pin (PA.06) to SPIz MISO pin (PB.14).
 * Connect SPIy MOSI pin (PA.07) to SPIz MOSI pin (PB.15).

 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"
/** board specific*/
#define SPI_MASTER SPI1
#define SPI_MASTER_CLK RCC_APB2Periph_SPI1
#define SPI_MASTER_GPIO GPIOA
#define SPI_MASTER_GPIO_CLK RCC_APB2Periph_GPIOA
#define SPI_MASTER_PIN_CSN GPIO_Pin_4
#define SPI_MASTER_PIN_SCK GPIO_Pin_5
#define SPI_MASTER_PIN_MISO GPIO_Pin_6
#define SPI_MASTER_PIN_MOSI GPIO_Pin_7
#define SPI_MASTER_DR_Base (SPI1_BASE + 0x0004)
#define SPI_MASTER_DT_Base SPI1_BASE

#define SPI_SLAVE SPI2
#define SPI_SLAVE_CLK RCC_APB1Periph_SPI2
#define SPI_SLAVE_GPIO GPIOB
#define SPI_SLAVE_GPIO_CLK RCC_APB2Periph_GPIOB
#define SPI_SLAVE_PIN_CSN GPIO_Pin_12
#define SPI_SLAVE_PIN_SCK GPIO_Pin_13
#define SPI_SLAVE_PIN_MISO GPIO_Pin_14
#define SPI_SLAVE_PIN_MOSI GPIO_Pin_15
#define SPI_SLAVE_DR_Base (SPI2_BASE + 0x0004)
#define SPI_SLAVE_DT_Base SPI2_BASE
/* Private typedef -----------------------------------------------------------*/
typedef enum { FAILED = 0, PASSED = !FAILED } TestStatus;

/* Private define ------------------------------------------------------------*/
#define BufferSize 32

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
SPI_InitTypeDef SPI_InitStructure;
DMA_InitTypeDef DMA_InitStructure;
USART_InitTypeDef USART_InitStructure;

uint8_t dmaSPI_MASTER_Buffer_Tx[BufferSize] = {
    0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
    0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16,
    0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20};
uint8_t dmaSPI_SLAVE_Buffer_Tx[64] = {
    0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B,
    0x5C, 0x5D, 0x5E, 0x5F, 0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66,
    0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70};
uint8_t dmaSPI_SLAVE_Buffer_Rx[BufferSize];
uint8_t dmaSPI_MASTER_Buffer_Rx[BufferSize];
__IO uint8_t dmaTxIdx = 0;
__IO uint8_t dmaRxIdx = 0;
__IO uint8_t k = 0;
__IO TestStatus TransferStatus1 = FAILED;
__IO TestStatus TransferStatus2 = FAILED;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void GPIO_Configuration(void);
TestStatus Buffercmp(uint8_t *pBuffer1, uint8_t *pBuffer2,
                     uint16_t BufferLength);

/* Private functions ---------------------------------------------------------*/

void main(void) {
  NopDelay(0xFFFF);
  pll_init();

  sys_io_init();

  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  RCC_Configuration();
  GPIO_Configuration();

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA, ENABLE);

  DMA_Cmd(DMA_Channel1, DISABLE);
  DMA_Cmd(DMA_Channel2, DISABLE);

  DMA_DeInit(DMA_Channel1);
  DMA_StructInit(&DMA_InitStructure);
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SPI_MASTER_DT_Base;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)dmaSPI_MASTER_Buffer_Tx;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
  DMA_InitStructure.DMA_BufferSize = BufferSize;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_InitStructure.DMA_PeripheralHandshake = DMA_PeripheralHandshake_SPI1_TX;
  DMA_Init(DMA_Channel1, &DMA_InitStructure);
  debug("DMA1 transfer data length: %d\r\n",
        DMA_GetCurrDataCounter(DMA_Channel1));

  DMA_DeInit(DMA_Channel2);
  DMA_StructInit(&DMA_InitStructure);
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SPI_SLAVE_DT_Base;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)dmaSPI_SLAVE_Buffer_Tx;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
  DMA_InitStructure.DMA_BufferSize = BufferSize;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_InitStructure.DMA_PeripheralHandshake = DMA_PeripheralHandshake_SPI2_TX;
  DMA_Init(DMA_Channel2, &DMA_InitStructure);
  debug("DMA3 transfer data length: %d\r\n",
        DMA_GetCurrDataCounter(DMA_Channel2));

  SPI_DeInit(SPI_MASTER);
  SPI_DeInit(SPI_SLAVE);

  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;

  /** Configure SPI MASTER*/
  SPI_Init(SPI_MASTER, &SPI_InitStructure);

  /** Configure SPI SLAVE*/
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Slave;
  SPI_Init(SPI_SLAVE, &SPI_InitStructure);
  /* Enable SPI_MASTER DMA request */
  SPI_DMACmd(SPI_MASTER, SPI_DMAReq_Tx, ENABLE);
  SPI_DMACmd(SPI_SLAVE, SPI_DMAReq_Tx, ENABLE);
  /** Enable SPI MASTER CSN */
  SPI_SSOutputCmd(SPI_MASTER, ENABLE);
  /** Enable SPI MASTER */
  SPI_Cmd(SPI_MASTER, ENABLE);
  /** Enable SPI SLAVE */
  SPI_Cmd(SPI_SLAVE, ENABLE);

  DMA_Cmd(DMA_Channel2, ENABLE);
  NopDelay(0xF);
  DMA_Cmd(DMA_Channel1, ENABLE);

  /* Wait for DMA transmission to complete */
  while (DMA_GetFlagStatus(DMA_FLAG_TC1) == RESET) {
  }
  while (DMA_GetFlagStatus(DMA_FLAG_TC2) == RESET) {
  }

  NopDelay(0xFFFF);
  while (dmaRxIdx < BufferSize) {

    if (SPI_GetFlagStatus(SPI1, SPI_FLAG_RXNE) != RESET) {
      dmaSPI_MASTER_Buffer_Rx[dmaRxIdx] = SPI_ReceiveData(SPI1);
    }
    if (SPI_GetFlagStatus(SPI2, SPI_FLAG_RXNE) != RESET) {
      dmaSPI_SLAVE_Buffer_Rx[dmaRxIdx] = SPI_ReceiveData(SPI2);
    }
    dmaRxIdx++;
  }
  NopDelay(0xFFFF);

  for (k = 0; k < BufferSize; k++) {
    debug("%d %d \n", dmaSPI_SLAVE_Buffer_Rx[k], dmaSPI_MASTER_Buffer_Rx[k]);
  }

  SPI_SSOutputCmd(SPI_MASTER, DISABLE);
  SPI_Cmd(SPI_MASTER, DISABLE);
  SPI_Cmd(SPI_SLAVE, DISABLE);

  SPI_DMACmd(SPI_MASTER, SPI_DMAReq_Tx, DISABLE);
  SPI_DMACmd(SPI_SLAVE, SPI_DMAReq_Tx, DISABLE);

  /* Check the correctness of written data */
  TransferStatus1 =
      Buffercmp(dmaSPI_SLAVE_Buffer_Rx, dmaSPI_MASTER_Buffer_Tx, BufferSize);
  TransferStatus2 =
      Buffercmp(dmaSPI_MASTER_Buffer_Rx, dmaSPI_SLAVE_Buffer_Tx, BufferSize);

  if (TransferStatus1) {
    debug("masterSPI->slaveSPI;slaveRx->DMA TransferStatus = [PASSED]!!!\n");
  } else {
    debug("masterSPI->slaveSPI;slaveRx->DMA  TransferStatus = [FAILED]!!!\n");
  }

  if (TransferStatus2) {
    debug("slaveSPI->masterSPI;masterRx->DMA TransferStatus = [PASSED]!!!\n");
  } else {
    debug("slaveSPI->masterSPI;masterRx->DMA  TransferStatus = [FAILED]!!!\n");
  }
  while (1) {
  }
}

/**
 * @brief  Configures the different system clocks.
 * @param  None
 * @retval None
 */
void RCC_Configuration(void) {
  /* PCLK2 = HCLK/2 */
  RCC_PCLK2Config(RCC_HCLK_Div2);
  /**  Enable SPI1 clock and GPIO clock for SPI1 and SPI2 */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOA |
                             RCC_APB2Periph_SPI1,
                         ENABLE);
  /**  Enable SPI2 Periph clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
}

/**
 * @brief Config SPI1&SPI2GPIO
 */
void GPIO_Configuration(void) {
  GPIO_InitTypeDef GPIO_InitStructure;

  /** Remap SPI1 use PA4 PA5 PA6 PA7 */
  GPIO_PinRemapConfig(GPIO_Remap_SPI1, DISABLE);
  /** Remap SPI2 use PB12 PB13 PB14 PB15 */
  GPIO_PinRemapConfig(GPIO_Remap_SPI2, ENABLE);
  /* Configure SPIx as AF mode */
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = SPI_MASTER_PIN_CSN | SPI_MASTER_PIN_SCK |
                                SPI_MASTER_PIN_MOSI | SPI_MASTER_PIN_MISO;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_Init(SPI_MASTER_GPIO, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = SPI_SLAVE_PIN_CSN | SPI_SLAVE_PIN_SCK |
                                SPI_SLAVE_PIN_MOSI | SPI_SLAVE_PIN_MISO;
  GPIO_Init(SPI_SLAVE_GPIO, &GPIO_InitStructure);
}

/**
 * @brief  Compares two buffers.
 * @param  pBuffer1, pBuffer2: buffers to be compared.
 * @param  BufferLength: buffer's length
 * @retval PASSED: pBuffer1 identical to pBuffer2
 *         FAILED: pBuffer1 differs from pBuffer2
 */
TestStatus Buffercmp(uint8_t *pBuffer1, uint8_t *pBuffer2,
                     uint16_t BufferLength) {
  while (BufferLength--) {
    if (*pBuffer1 != *pBuffer2) {
      return FAILED;
    }

    pBuffer1++;
    pBuffer2++;
  }

  return PASSED;
}
