/**
 * @file main.c
 * @brief tamper example
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"
uint32_t counter = 0;
void TAMPER_IRQHandler(void) {
  debug("enter tamper interrupt!\n");
  BKP_TamperClearIT();
}

void main(void) {

  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  RTC_SelClk(RTC_LSE);

  ECLIC_Register_IRQ(TAMPER_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
                     ECLIC_LEVEL_TRIGGER, 2, 0, (void *)TAMPER_IRQHandler);
  __enable_irq();

  BKP_TamperInit();
  BKP_TamperPinLevelConfig(BKP_TamperPinLevel_Low, BKP_Tamper_no_debouce);
  BKP_TamperPinCmd(ENABLE);
  BKP_TamperIrqEnable();

  BKP_WriteBackupRegister(BKP_DR1, 0x1A20);
  BKP_WriteBackupRegister(BKP_DR2, 0x1A21);
  BKP_WriteBackupRegister(BKP_DR3, 0x1A23);
  BKP_WriteBackupRegister(BKP_DR4, 0x1A24);
  BKP_WriteBackupRegister(BKP_DR5, 0x1A25);
  BKP_WriteBackupRegister(BKP_DR6, 0x1A26);
  BKP_WriteBackupRegister(BKP_DR7, 0x1A27);
  BKP_WriteBackupRegister(BKP_DR8, 0x1A28);
  BKP_WriteBackupRegister(BKP_DR9, 0x1A29);
  BKP_WriteBackupRegister(BKP_DR10, 0x1A2A);

  while (1) {
    debug("BKP1 = %x\n", BKP_ReadBackupRegister(BKP_DR1));
    debug("BKP2 = %x\n", BKP_ReadBackupRegister(BKP_DR2));
    debug("BKP3 = %x\n", BKP_ReadBackupRegister(BKP_DR3));
    debug("BKP4 = %x\n", BKP_ReadBackupRegister(BKP_DR4));
    debug("BKP5 = %x\n", BKP_ReadBackupRegister(BKP_DR5));
    debug("BKP6 = %x\n", BKP_ReadBackupRegister(BKP_DR6));
    debug("BKP7 = %x\n", BKP_ReadBackupRegister(BKP_DR7));
    debug("BKP8 = %x\n", BKP_ReadBackupRegister(BKP_DR8));
    debug("BKP9 = %x\n", BKP_ReadBackupRegister(BKP_DR9));
    debug("BKP10 = %x\n", BKP_ReadBackupRegister(BKP_DR10));
  }
}
