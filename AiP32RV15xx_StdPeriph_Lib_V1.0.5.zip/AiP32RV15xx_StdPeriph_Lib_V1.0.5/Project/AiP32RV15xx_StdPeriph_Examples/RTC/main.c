/**
 * @file main.c
 * @brief This demo shows how to use RTC module.The current time can be printed
 * out through the serial port. Alarms can be set to generate interrupt.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

uint32_t bkp = 0;
uint32_t min, sec, hour, year = 0;
RTC_TimeTypeDef timeset;
RTC_TimeTypeDef time_alarm1;

void RTC_IRQHandler(void) {
  debug("enter RTC intrrupt!\n");
  RTC_ClearITPendingBit(RTC_IT_ALR1);
  RTC_ClearITPendingBit(RTC_IT_ALR2);
}

void main(void) {

  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  RTC_SelClk(RTC_LSE);
  ECLIC_Register_IRQ(RTC_IRQn, ECLIC_NON_VECTOR_INTERRUPT, ECLIC_LEVEL_TRIGGER,
                     2, 0, (void *)RTC_IRQHandler);
  __enable_irq();

  time_alarm1.Sec = 0x20;
  time_alarm1.Min = 0x5;
  time_alarm1.Hour = 0x6;
  /*set the alarm1*/
  RTC_SetAlarm(time_alarm1);
  /*set the interrupt output every 1/2 sec */
  RTC_SetSecINT(RTC_PERIOD_1_sec_2);

  timeset.Sec = 0x3;
  timeset.Min = 0x6;
  timeset.Hour = 0x9;
  /*set RTC */
  RTC_SetTimeDate(timeset);

  RTC->RTC_RDSTA_A7.RDSTA = 0x1;
  min = RTC->MINUTE.MIN;
  sec = RTC->SECOND.SEC;
  hour = RTC->HOUR.HOUR19;

  RTC->RTC_RDSTP_A7.RDSTP = 0x1;

  debug("sec = %x\n", sec);
  debug("min = %x\n", min);
  debug("hour = %x\n", hour);
  while (1) {
  }
}
