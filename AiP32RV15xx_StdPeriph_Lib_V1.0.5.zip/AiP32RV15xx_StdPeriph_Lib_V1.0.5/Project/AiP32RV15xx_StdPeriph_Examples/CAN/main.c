/**
 * @file main.c
 * @brief  The demo shows how to use CAN bus to transmit data .The baud rate of
 * CAN BUS is 1M.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"
#define CAN_TX 1
#define CAN_RX 1
GPIO_InitTypeDef GPIO_struct1;

CAN_InitTypeDef CAN_InitStructure;
CAN_FilterInitTypeDef CAN_FilterInitStructure;
CanTxMsg TxMessage;
CanRxMsg RxMessage;

void CAN_IRQHandler(void) {

  debug("enter interrupt!\n");
  if (CAN->ISR.RI == 0x1) {
    CAN_Receive(&RxMessage);
  }
  CAN_ITConfig(CAN_IT_RI, ENABLE);
  CAN_ClearITPendingBit(CAN_IT_RI);
}

void can_cfg(void);
void main(void) {
  uint16_t i = 0;
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);
  RCC_PCLK1Config(3); /*16M*/
#if CAN_RX
  ECLIC_Register_IRQ(CAN_IRQn, ECLIC_NON_VECTOR_INTERRUPT, ECLIC_LEVEL_TRIGGER,
                     2, 0, (void *)CAN_IRQHandler);
  __enable_irq();
#endif
  GPIO_struct1.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_0;
  GPIO_struct1.GPIO_Mode = GPIO_Mode_AF;
  GPIO_Init(GPIOD, &GPIO_struct1);
  GPIO_PinRemapConfig(GPIO_Remap2_CAN, ENABLE);

  can_cfg();

  /* Transmit */
  TxMessage.ExtId = 0x156789;
  TxMessage.RTR = CAN_RTR_Data;
  TxMessage.IDE = CAN_Id_Extended;
  TxMessage.DLC = 8;
  for (i = 0; i < 8; i++)
    TxMessage.Data[i] = i;

  while (1) {
#if CAN_TX
    if (CAN->STATUS.TBS == 0x1)
      CAN_Transmit(&TxMessage);
#endif
  }
}

void can_cfg() {
  CAN_Mode_Set(CAN_Mode_Reset);
  CAN_ITConfig(CAN_IT_RI, ENABLE);
  CAN_InitStructure.CAN_Prescaler = 0x0;
  CAN_InitStructure.CAN_SJW = 0x3;
  CAN_InitStructure.CAN_BS1 = 0x9;
  CAN_InitStructure.CAN_BS2 = 0x6;
  CAN_InitStructure.CAN_SAM = 0x1;
  CAN->AMR.value = 0xffffffff;
  CAN->ACR = 0;
  CAN_Init(&CAN_InitStructure);

  CAN_Mode_Set(CAN_Mode_Normal);
}
