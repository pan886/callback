/**
 * @file main.c
 * @brief  This example provides an interrupt implementation of the watchdog.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

void WWDG_Init() {
  /*enable the WDT*/
  WWDG_Enable();
  /*set the mode of WDT*/
  WWDG_SetMode(INTERRUPT_MODE);
  /*set the prescale divisor*/
  WWDG_SetPrescaler(WWDG_Higher_Prescaler_2, WWDG_Lower_Prescaler_1);
  /*set the length of reset pluse*/
  WWDG_Set_Reset_Pulselength(0xffff);
  /*Reloads WWDG counter*/
  WWDG_SetReload(0x3FFFF);
  /*set the timeout range*/
  WWDG_Set_Timeout_range(Counter_Cycles_64);
  /*Restart the WWDG counter.*/
  WWDG_ReloadCounter();
}

void WWDGT_IRQHandler(void) {
  /* the interrupt status of the WDT*/

  WWDG_ClearFlag();
  WWDG_Init();
  debug("enter WDT interrupt!\n");
}

int main(void) {

  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);

  ECLIC_Register_IRQ(WWDGT_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
                     ECLIC_LEVEL_TRIGGER, 3, 0, (void *)WWDGT_IRQHandler);

  __enable_irq(); /* enable global interrupt */
  WWDG_Init();

  debug("running\n");

  while (1) {
  }
}
