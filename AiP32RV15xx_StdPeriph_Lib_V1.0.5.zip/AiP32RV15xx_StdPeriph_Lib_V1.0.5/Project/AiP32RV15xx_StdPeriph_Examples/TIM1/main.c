/**
 * @file main.c
 * @brief timer1 interrupt example
 *
 * @author MCD Application Team
 * @version 1.0
 * @date 2024-11-8
 * @copyright Copyright (c) 2024 Icore, Inc
 */

#include "AiP32RV15xx.h"

void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint16_t PortVal) {
  GPIOx->DATA ^= PortVal;
}

void TIMER1_UD_IRQHandler() {
  if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET) {
    /* Clear the interrupt flag bit */
    GPIO_Toggle(GPIOE, GPIO_Pin_2);

    TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
  }
}

void main(void) {
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  pll_init();
  sys_io_init();
  uart_init(UART_BOOT_PORT, UART_PARITY_NONE, UART_STOPBITS_1, UART_DATABITS_8,
            UART_BOOT_BD);
  TIM_InternalClockConfig(TIM1);

  /* GPIO configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  /*initialization pin PE2 PE3 PE4 PE5 PE6*/
  GPIO_Init(GPIOE, &GPIO_InitStructure);

  ECLIC_Register_IRQ(TIM1_UP_IRQn, ECLIC_NON_VECTOR_INTERRUPT,
                     ECLIC_LEVEL_TRIGGER, 1, 0, (void *)TIMER1_UD_IRQHandler);

  __enable_irq();

  /* TIM1 clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Period = 999;
  TIM_TimeBaseStructure.TIM_Prescaler = 899;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV4;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
  /* Enables TIM1 interrupt */
  TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

  /* TIM1 counter enable */
  TIM_Cmd(TIM1, ENABLE);

  while (1) {
  }
}
