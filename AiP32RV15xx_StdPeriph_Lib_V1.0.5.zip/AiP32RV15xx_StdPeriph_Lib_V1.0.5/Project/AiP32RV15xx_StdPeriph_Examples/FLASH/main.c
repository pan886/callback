/**
 * @file main.c
 * @brief  flash module example.
 * @author MCD Application Team
 * @version 1.0
 * @date 2022-03-16
 * @copyright Copyright (c) 2022 Icore, Inc
 */

#include "AiP32RV15xx.h"

#define NOP() asm("nop")
int read_mem(int addr) {
  int rdval;
  rdval = *(int *)addr; /*read value from data memory*/
  return rdval;
}

void write_mem(int addr, int val) {
  *(int *)addr = val; // store value in data memory
}

int Number = 0;
int COUNT = 0;
int CHECK = 0;
int CHECKRIGHT = 0;
int i = 0;
int read_data;
#define SECTOR_SIZE 0x80
#define TEST_SIZE 0X7400 /* 116KB*/
void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint16_t PortVal);
void delay_ms() {
  uint16_t i = 0xaaa;
  while (i-- > 0)
    NOP();
}
void main(void) {
  int abc = 1;

  int sector = 16;
  int addr_EFLASH = FLASH_BASE + sector * SECTOR_SIZE * 4;
  int err_flag = 0;
  int option_byte_addr = FLASH_BASE + 0x20BF0;
  int P = 101;
  while (P-- > 0)
    delay_ms();
  pll_init();
  sys_io_init();
  FLASH_Unlock();
  for (i = 0; i < 233; i++) {
    FLASH_EraseSector((i * 0x200) + sector * SECTOR_SIZE * 4);
    do {
      read_data = FLASH->STS0.CURR_STATUS;
    } while (read_data & 0xf == 0x3); /*sector erase state*/
    do {
      read_data = FLASH->STS0.CURR_STATUS;
    } while (read_data & 0xf != 0x0); /* idle state*/
  }
  COUNT = 0;
  while (1) {
    FLASH_Unlock();

    for (i = 0; i < TEST_SIZE + 1; i++) {
      write_mem(addr_EFLASH + (i)*4, Number);
    }
    do {
      read_data = FLASH->STS0.CURR_STATUS;
    } while (read_data & 0xf != 0x0); /*idle state*/

    for (i = 0; i < TEST_SIZE + 1; i++) {
      read_data = read_mem(addr_EFLASH + (i)*4);
      if (read_data != (Number)) {
        GPIO_Toggle(GPIOE, GPIO_Pin_3);
        CHECK++;
      } else {
        CHECKRIGHT++;
      }
    }

    for (i = 0; i < 30; i++) {
      FLASH_EraseBlock((i * 0x1000) + sector * SECTOR_SIZE * 4);
      do {
        read_data = FLASH->STS0.CURR_STATUS;
      } while (read_data & 0xf == 0x4); /*BLOCK erase state*/
      do {
        read_data = FLASH->STS0.CURR_STATUS;
      } while (read_data & 0xf != 0x0); /*idle state*/
    }

    Number++;
  }
}
void GPIO_Toggle(GPIO_TypeDef *GPIOx, uint16_t PortVal) {
  GPIOx->DATA ^= PortVal;
}
